# Public-stance research: final coverage

Completed 2026-11-06T06:18:48.933276+00:00. The election/stance snapshot remains frozen at November4,2026 America/New_York; later discoveries are not silently treated as evidence available at that cutoff.

| Office | Seat packets independently reviewed |
|---|---:|
| Voting House |435|
| Senate |100|
| State governors |50|
| Nonvoting delegates/resident commissioner, separately |6|
| Total |591|

All 591 scoped packets have an independent review and an explicit integration disposition. Documented active research floors are satisfied for 640 scoped actor/seat entries; this is not a count of640 unique politicians. Two unidentified future appointees have no person to time and remain exempt. TX/NJ/OH/PA use600seconds; other members300seconds. Reported closed active segments exclude recorded interruptions; these documents cannot independently replay past runtime.

522 incoming/returning/holdover identities have reviewed source support. 69 incoming identities remain unknown at the frozen cutoff, including two pending Senate appointments. Predecessor and candidate evidence remains separate; projections and original local winner reports are not certification. Thirteen blocked queue states preserve eleven reviewed comparison packets and two unidentified appointments; they do not represent unfinished review. Unknown is not neutral.

The immutable consolidated dataset contains5,119 bounded reviewed records, including one nonperson legislative-context record excluded from personal stance eligibility. A seat with reviewed clauses may contain predecessor/comparison evidence, so556 export-bearing seats is not a count of known incoming stances. 489 clause holds remain inspectable. All historical85 records have explicit dispositions:26 narrow exports,50 provenance/context-only records,nine preserved holds. Ten exact identity bridges and five distinct delegate joins have reviewed provenance and zero unmatched joins.

Data-center buildout policy remains separate from general AI policy. Bill proposals, procedural votes, enacted law and actual administrative actions remain distinct. Public stances alone do not establish political effects on delivered GW or project delays. SemiAnalysis and numerical scenarios remain deferred.

Named minor candidates Curtis Goodwin and Robert Luffman and specified write-ins are explicit scope exclusions, not claims of completed individual stance research. This is coverage of incoming members/likely contenders, not a complete-field candidate census or an exhaustive answer on every policy topic.

## Inspect the results

- [Seat-by-seat checklist (CSV)](reviews/final-review6-audits/20261106T052333Z/seat-checklist.csv)
- [Machine-readable checklist](reviews/final-review6-audits/20261106T052333Z/seat-checklist.jsonl)
- [Documented person/seat timing](reviews/final-review6-audits/20261106T052333Z/person-timing-ledger.jsonl)
- [Detailed limitations and69 unknown identities](reviews/final-review6-audits/20261106T052333Z/remaining-gaps.md)
- [Reviewed records](data/reviewed-consolidated/20261106T052329Z/records.jsonl)
- [Held clauses](data/reviewed-consolidated/20261106T052329Z/holds.jsonl)
- [Reviewed context and provenance](data/reviewed-consolidated/20261106T052329Z/context.jsonl)
- [Root consistency/hash verification](reviews/root-final-verification.json)

Root recomputed1,119 original-record/selected-manifest hashes and checked591unique seats, office counts,640 documentary floors,69unknown identities and5,119 unique stable IDs. Independent review also verified prior research hashes and preserved review-version lineage. Historical generated snapshots have verified lossless archives and a tested restore command; original research and raw review versions remain intact.

## Delivery and automation

The existing private dashboard remains affected by the enforced403 destination block. No live-site or successful production-update claim is made. Local final artifacts are the deliverable; the existing Site and storage are preserved.

The dispatcher automation `6aec01bba820819184d19264133c6951` is disabled, confirmed by the supported automation service. No active research seat leases remain. Original source files, disagreements, records and leases/history are retained.
