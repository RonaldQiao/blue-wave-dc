Candidate dossier: US-GOV-RI — Helena Foulkes, Governor-elect of Rhode Island

Election verified through original Nov 3 Rhode Island Current and Ocean State Media reports, including AP call8:30 pm; called winner, not certification. McKee is outgoing predecessor, never the incoming actor. No assumed vote totals from provisional WSJ arithmetic.

Foulkes directly answered yes to a statewide data-center ban in Aug 28 PBS interview. Transcript speaker boundary verified: Foulkes thanked atL495; McKee introducedL499. Search snippets sometimes display McKee's different answer, so use Foulkes L470-472. Aug 4 Journal interview (published Aug 26, read viaAOL) only said open to moratorium; retain chronology. Ban's size threshold, duration, exemptions, treatment of existing sites and executive/statutory route unspecified; no enacted ban attributed to her.

April campaign PDF, six pages, accessed at Coalition News mirror: p3 requires heavy users including DCs to bear own energy costs, advocates consumer protection and exploration of approaches. Retain alongside ban, without manufacturing an exception. Aug 18 debate original local report independently establishes opposition to proposed DC-equipment sales-tax exemption. WPRI debate video restricted; original Journal article restricted; accessible syndicated body read. Neither legislative sponsors nor20/50MW bill thresholds are Foulkes policy.

General energy: faster renewables interconnection, GETs prioritized over expensive new transmission,40 million USD solar/battery program,250 public buildings first two years. All proposals. Pipeline skepticism is qualified. LaterOct 1/26 reporting favors retaining renewable deadlines; Oct 25 ecoRI reprint recalls April openness—retain date/source tension. No McKee state solar project credited to Foulkes.

AI separately: Aug 18 agreed to60-day Flock installation pause and questioned timing; Sep 4 syndicatedAP confirms surveillance-data-use review support. This is surveillance governance, not blanket AI policy or physical DC stance. No own quantified water cap or comprehensive AI safety rules located; unknown is not neutrality.

Access notes: own campaign homepage read post-election; plans and PDF redirect inaccessible, transition unavailable. Linked Coalition PDF first retrieved with text and precise page locators; later absoluteURL failed, recovered through tool reference. No screenshots/video/audio used. 350endorsement unavailable; April Progressive reprint429. Broad aggregator no-position claims contradicted by direct interview; not adopted.

All records candidate, awaiting independent review; no canonical edits, selfapproval or causal capacity/delay estimate. Durable timing closes conservatively at checkpoints across recovery. Final timing.json governs300 active-second floor.
