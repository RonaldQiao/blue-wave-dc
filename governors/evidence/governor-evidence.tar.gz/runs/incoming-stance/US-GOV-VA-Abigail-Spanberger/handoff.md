US-GOV-VA — Abigail Spanberger — candidate submission, independent review required.

Actual holdover established by Jan17,2026 inauguration, ArtV§1 four-year term and official2026–2030 election calendar: next governor voteNov6,2029. Expected successor inaugurationJan19,2030 is calendar inference, not an observed future event. Democratic party confirmed by NGA. Governor office, districtnull; Youngkin predecessor only.

Assessment: conditional/mixed physical-development stance. Own statements support continued investment under stronger standards; tax, permitting, environmental and cost safeguards preserved separately. Newest personal evidenceOct28 NBC interview excerpt, publishedOct29. No capacity/delay inference.

Review priorities:
- R3–R8: signedEO22. Distinguish presently binding instructions from studies/deadlines and later rulemaking; total executive-order source-derived prose kept short. No implemented universal gas ban, existing-generator retrofit requirement or local NDA ban established.
- R9–R11: separate2027 framework aspirations. Not all speech present-tense wording describes existing law.
- R12–R19: signatures and operative chapters checked where possible. Current siting provision15.2-2209.5 differs from original Chapter567 section numbering; parking law now occupies15.2-2209.4. Mandatory sound assessment100MW threshold differs from proposed25MW local-approval framework. Other-resource assessments discretionary.
- R18–R19 use finalHB30 Chapter1, not enrolled copy. Tax and exemption separate. Original enrolled link had click-resolution failure, corrected by direct chapter URL.
- R20–R22 separate Governor advocacy from independent SCC decision and supplemental implementation. SCC explanation limits direct assignment prospectively to direct-connect facilities; no universal allocation of all regional grid costs claimed.
- R23/R28/R29 retain no-statewide-pause/local-discretion evidence and later water special-session denial. OriginalFOX caption opened, video not watched; attributed lower-quality evidence. Sep18 question evasion alone does not prove categorical opposition to every pause. Other legislators moratorium bills are not hers.
- R26 expert-backed merger demand remains advocacy; detailed full filing uninspected. R24 AI governance excluded from facility stance.

Access: LIS bill detail returned JS shell. Outbound SCC order tracking link403; original agency explanation used. Virginia Lawyers Weekly403, CapeCharlesMirror502; neither full article treated as read. No access-control bypass. Videos not independently played. Latest broad/official searches foundOct material, without inventing additional later position. Exact queries reconstructed in search-log at durable milestone; those timestamps are logging times, not invented search-start clocks.

29 candidate records /32 source records. Canonical actor/tenure joins remain null. Legal-effect flags confined to retrieved operative sources, others documented as reported signatures/proposals/advocacy. Genuine timing excludes compaction; see timing.json. Submitted does not mean accepted. No canonical exports modified.
