# Candidate handoff: US-GOV-WI David Crowley

Governor of Wisconsin, district null; incoming AP-called winner, current Milwaukee County executive. Tony Evers outgoing predecessor only. AP original dispatch called Nov3 23:28EST (Nov4 04:28UTC). Certification/oath unverified.

Latest own original WPR interview (Oct22 inferred; publishedOct26 updatedOct27) supports conditional statewide pause during environmental review, repeal of data-center sales-tax exemption, local choice and legislative guardrails. Oct19 spokesperson specifies review completion AND guardrails. Earlier July/Aug opposition to one-year moratorium and automatic blanket incentive rollback remains explicit contrary evidence, alongside Nov2025 growth/hub rhetoric. July/Aug proposals require full power/grid costs, new renewable supply, Focus on Energy payments, local NDA ban, labor/community benefits and water/farmland protections.

Primary individual action: county executive signed Milwaukee County25-781 Dec23 2025. Engrossed county advocacy urges state AB722/SB729 conditioned on government energy-fee exemption. This is not enacted state legislation or Crowley state-bill sponsorship. Official signature attachment unavailable410; official history confirms signing. Official state bill pages inaccessible.

Important factual limit: his existing de-facto-moratorium description is unsupported as law. Filed Oct16 settlement requires DNR review by Jan31 2028 and expressly preserves Lighthouse permits; WPR says statewide permitting is not halted. Pause remains campaign proposal, not observed implemented governor action. Daily Cardinal debate wording (Milwaukee pause/neither full moratorium) conflicts in scope/terminology; own later statewide answer retained.

AI/social-media protections recorded separately. No inferred federal votes, project delays, capacity effects, implemented tariffs or universal project opposition. Candidate records await independent review. Source access failures and undated campaign-index limitations preserved. Timing segments exclude compaction; see timing.json.

Nov5 original postelection report on Nov4 press availability checked: transition cabinet/team being assembled; no new specific physical-DC legislation established.19sources17records18logged search families.

Final source register20: attempted original July24 Journal Sentinel interview linked by Examiner; unavailable nonretryable error, so earlier own statement remains attributable reporting with exact interview date unknown. Original Courier and Aug18 Examiner bodies rechecked to confirm cost, local choice and earlier opposition.
