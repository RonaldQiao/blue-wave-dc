# Byron Donalds — Florida governor incoming candidate handoff

Candidate research only; independent review and canonical actor/tenure integration remain required. Queue seat US-GOV-FL; office Governor of Florida; district null. Incoming executive record is separate from congressional actions performed as Florida19 Representative.

## Incoming-office gate

NPR's original November3 report (published9:10PMEST, E1) attributes Donalds's victory over David Jolly to AP's call. News Service of Florida's November4 original report (E2) adds concession/returns evidence. These establish a reported winner, not certification or an exact AP call minute. Ron DeSantis is outgoing predecessor. Under Florida Constitution ArticleIV§5(a), expected term starts January5,2027; calculated from the constitutional rule. Donalds's current House title does not make this a House-seat result.

## Physical-buildout conclusion

Conditional/mixed is supported by his own July20 announcement (R2), rejection of a statewide moratorium (R3), and subsequent local-control/water/bill conditions (R5–R7). He favors domestic construction with safeguards and allows local rejection. This is neither blanket opposition nor an unconditional project endorsement. Historical supportive language is retained separately in R11, with unresolved May-versus-June2025 dating and inaccessible original video. No automatic supersession is claimed.

## Actions, scope, and counterevidence

- H.R.9777: official introduced July20 text verifies sponsorship and referral. His proposal requires covered centers, including existing facilities, to obtain independent power/water after enactment. Office draft dated July14 is not introduction evidence. Latest legislative status remains inaccessible; no enactment asserted.
- September16 H.R.9340 vote: Clerk independently verifies Yea and House passage; official House text concerns incremental utility-upgrade costs and financial assurances for covered100MW IT campuses. PURPA consideration/determination timelines and prior-state-action exceptions matter. This is distinct from H.R.9777 and is not a universal automatic guarantee.
- State SB484/chapter2026-65 is an enacted action of Florida state institutions, not Donalds's House vote or gubernatorial signature. His blanket claim about bills is broader than its reasonably-ensure tariffs and utility coverage. Operative water provisions retain feasibility/permit conditions. Study is due July1,2027, correcting his repeated June1 assertion. Local planning authority is retained.
- May22,2025 H.R.1 omnibus Yea and its contemporaneous AI-enforcement pause are recorded separately. A critical report's claim that it blocked physical siting is not adopted as a legal conclusion. House version differs from final text; later reported disagreement is R12. Votes do not alone establish motive.
- Own November5,2025 letter expressly connects data-center demand to nuclear deployment and SMRs. It is advocacy, not project permission. General gas/nuclear preferences and AI child safety remain separate from construction stance.

## Access and precision limits

Congress.gov latest-status URL was inaccessible; GovInfo XML returned unsupported content type. Campaign site inaccessible; Florida Politics402; X403; linked YouTube/Facebook videos throttled; Local10 body unavailable. No restriction bypass used. Web reference collisions were corrected with full original URLs. The old interview's month and several interview recording dates remain unresolved. WUFT incorrectly calls federal H.R.9777 a state Legislature bill; primary text controls. No actor-specific tax incentive, transmission-project permit, or numeric setback was established. Unknown fields are not neutral stances.

26 sources,14 candidate records,54 search-log entries. Timing is conservatively segmented with compaction excluded; minimum300 active seconds applies. All records remain candidate, legal effect is not inferred from proposals or House-only passage.
