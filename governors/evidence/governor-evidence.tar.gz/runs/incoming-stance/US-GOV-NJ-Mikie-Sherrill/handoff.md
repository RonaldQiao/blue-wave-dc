# US-GOV-NJ — Mikie Sherrill

Candidate research dossier; independent review required. Office: Governor of New Jersey. Canonical queue/seat ID: US-GOV-NJ. No House district and no federal roll calls are assigned to this office.

## Actor and timing

NGA's current governor page verifies Mikie Sherrill, Democratic, term January20,2026–current. Its original election calendar marks Sherrill the 2025 winner and New Jersey terms as four years. She is a genuine holdover, not a candidate in a fabricated2026 gubernatorial election;2029 is the next regular election by this calendar. Phil Murphy is predecessor only. This is not verification by merely assuming the queue's incumbent continues.

Active research began17:56:24UTC November5. The63seconds through17:57:27 are retained. Context compaction17:57:27–17:59:32 is excluded; research resumed17:59:32. Final timing.json contains actual completion time and summed active segments. The NJ600-second floor must be met before queue submission; this handoff's presence alone does not establish that it has been met.

## Synthesis

A conditional/mixed physical-buildout stance is supported. Sherrill's May27 plan welcomes investment under energy/grid-cost, clean-power, transparency, community-benefit and labor conditions. July7 FairShare enactment and August27 reporting enactment turn parts of the plan into statutory frameworks. August25 DCA guidance and the NJEDA hub provide municipal negotiation assistance. September22 environmental enforcement illustrates conditions on an actual Vineland facility. October20 shared-supercomputer investment is specific counterevidence to an interpretation of blanket opposition.

The October20 NJ Supercomputer Initiative is more concrete than generic AI enthusiasm: the governor commits public investment and a shared physical supercomputer hosted in EXISTING SHI New Jersey facilities, with new clean energy promised. It is not approval of a new hyperscale campus. Operation, delivered MW and execution of the clean-energy commitment were not verified. The state$25m was appropriated in the FY2026 budget; no Sherrill appropriation-signature attribution is made.

September21 PBS has an original host paraphrase that Sherrill opposes a statewide moratorium and favors municipal choice. The original POLITICO story/interview is identified but restricted, so this stays secondary attribution. Andrew Macurdy's adjacent subsidy criticism and openness to a pause are his views, never imported as Sherrill's. There is no verified blanket statewide prohibition in this dossier.

## Legal and attribution cautions

- FairShare: original July7 signature announcement, OLS digest P.L.2026,c.32 and final A796 fourth reprint agree on enactment. BPU standards are due within12months, utility tariff petitions within180days of the standards. The current original RFI schedules a November4 meeting and accepts comments until November13: ongoing development, not evidence of final statewide rates or proof that the scheduled meeting occurred.
- Final A796 incentivizes own NEW clean generation/storage and prioritizes binding generation/demand-reduction commitments. The August press release's shorthand that centers must bring their own clean energy should not override the actual final text. A BPU-set minimum size designation cannot exceed50MW; this is not one universal statutory50MW floor. Aggregation and anti-evasion rules matter. Priority emergency curtailment has a designated critical-load exception. The85% electricity-supply commitment lasts10years or as BPU otherwise determines.
- S3379: original OLS digest identifies P.L.2026,c.75, August27. Final second reprint includes healthcare internal-use exclusion, first-report3/6month deadlines, a three-year period beginning with each first report, BPU continuation decision and confidentiality for specified performance/sustainability information. Reporting is not a water-withdrawal ban, and not every reported field is necessarily publicly released.
- DCA CBA FAQ4 says no statutory requirement exists for municipalities to pursue a CBA. Guidance strongly recommends it and provides resources; do not turn this into a mandatory statewide agreement for every project.
- S4390: original NJEDA portal verifies Sherrill signed August27 P.L.2026,c.77 and applications are now closed because the remaining250m is fully allocated. Final reprint and committee statement remove the UNCOMMITTED250m from a500m allocation; the existing250m award is unaffected. Amounts return to Aspire/Emerge allocations: neither250m cash savings nor revocation of all data-center tax breaks is established. The digest's short synopsis retains energy-storage wording from an earlier version; final reprint/committee/EDA substance controls.
- Vineland: the governor's original September22 statement establishes public support for a DEP1.07m penalty assessment, following the July29 inspection of62 unpermitted generators. DEP release and original administrative-order PDF both returned403. Penalty collection, final adjudication, any stay, permit-or-cease deadline and whole-project shutdown are not independently established. NJ Monitor original reporting records a company dispute; this is not adjudication.
- Jan20 labor law P.L.2025,c.335 is real, but enactment occurred on inauguration day and the individual signatory was not established. It is NOT credited to Sherrill. Her own May construction/labor statement and later administrative guidance are separate evidence.
- EO2 original signed January20, section8, directs large-load/ghost-load monitoring. Original BPU budget response reports RFI/four utility responses. Agency implementation is not her personal quotation and does not establish achieved load-forecast correction or delivered generation.

## Access and coverage

12 candidate records and29 sources, including explicit unsuccessful-source entries. Search log covers originals, state bills/final reprints, agency implementation, tax incentives, water, labor, environmental enforcement, generation/grid, current contrary positions and AI separately. General AI support is separately coded. No probabilities, construction-delay estimates, canonical promotion or selfapproval.

Original POLITICO restricted; licensed Yahoo story429; Apple podcast404; DEP release/order403; public session-law PDF guesses inaccessible; NJleg bill-search page returned site chrome without JS details; EDA safe-link wrappers400. Public bill reprints, OLS digest and original signature announcements provided legal triangulation. Gothamist first viewport was readable through a normal publisher redirect, later opening returned500; no inaccessible office quotes are claimed. Third-party podcast transcripts, data-center aggregators and advocacy summaries are discovery leads only, not substitutes for governor attribution.

Validated JSON parsing, required record fields, unique IDs, source joins, candidate statuses and correct office/canonical IDs. Actor/tenure/party-source canonical joins remain null for integration. Review must retain stated scope, secondary attribution and unresolved legal outcomes.

Final statutory audit: A796 section2(g) exempts previously approved service MW from subsection(d)(1),(2),(8) guarantee/security/study-cost provisions, retains other requirements and allows phase-in of specified cost allocation. New/expanded service above the threshold is not exempt. Section2(f) ties application to tariff approval and pending-service commencement, with a BPU inequity exception. Record3 includes these limits; do not report universal retroactive85% guarantees.

Completed 2026-11-05T18:08:34.997295+00:00: 606.00 genuine active seconds, exceeding the600-second NJ floor. No additional substantive extension was necessary.
