# Candidate handoff — US-GOV-WA — Bob Ferguson

Office: Washington governor, Democratic actual holdover since January 15, 2025. Four-year constitutional term; next regular governor election2028. No invented2026racecall. PredecessorJayInslee distinct. All records candidate-only and require independent review.

Physical data centers: own EO25-05 balances industry growth against taxes, energy and sustainability. EO issuedFeb3,2025; releaseFeb4. Accessible DOR bulletin confirms scope; full governor/EO/report access403 is labeled. DOR current indexed notice holds finalreport until Tribal consultation finishes. Preliminary recommendations are not final governorpolicy.

Primary personal signatures: ESSB6231 April1,2026 9:57AM (chapter266) removes specified refurbishment/replacement incentives, retaining qualifying new construction. June11general/July1§§2–3effective. SSB5982 March24 10:41AM chapter181 extends defined CETA coverage/enforcement/reporting; emergencybackup and other statutory exclusions apply. HB2515 failed Senate; no Ferguson veto or personal endorsement of all its ratepayer/water provisions established.

Contrary/updated context: retained new-construction incentives and indexed April14IonQmanufacturing grant show continued selective investment. Oct26BeauPerschbacher event claims belong adviser, not Fergusonpersonalquote or verified water/community-harm findings. AGCOct19moratorium forecast is not own pledge. No own blanket statewide moratorium endorsement/rejection located; unknown is not neutrality. CarrigerDecember2025approval is solar, not data center.

AI separately: E2SHB1170 chapter167 signedMarch24 at10:04AM, future-effectiveFebruary1,2027, adds defined consumer-provider provenance and agency-AI disclosures with exclusions. Governor-requested HB2225 enactedMarch24chapter168, not effective untilJan1,2027. CompanionSB5984notseparateenactment. Consumer/minor/selfharm guardrails do not establish a physical DCposition.

Sources:32; records:18; audit:54. Exact locators and access limits preserved. No fullvideo/audio inspection claimed. No federalrollcalls assigned. Remaininggaps: finalreport/fullEO retrieval, project-specificpermitdecisions, personalcurrentmoratoriumcommitment, implementationorders. See timing.json for real segments, excluding compaction. Submission requires actual300active-second floor and guarded queuefinish.
