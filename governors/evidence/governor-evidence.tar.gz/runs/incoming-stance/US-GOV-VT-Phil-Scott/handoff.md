# US-GOV-VT — Phil Scott

Candidate research; independent review pending. Office: Governor of Vermont; canonical seat US-GOV-VT. Incumbent reelected, AP call Nov4 00:35EST and original VermontPublic confirmation; certification unverified.

Physical stance is qualified: vetoed H727 as excessive statewide regulation, while allowing a substantially revised bill and local restrictions. September comments say Vermont can prosper without facilities. Latest Oct14 reporting attributes conditional construction-moratorium support to campaign spokesman Dustin Degree, pending federal steps; retain this newer qualification. No permanent-ban pledge or unconditional project endorsement inferred. H727 veto survived; final replacement starts p22 of the39-page primary PDF. Earlier tariff versions appear before it and must not be treated as operative. Water150000gpd is a surfacewater review threshold, not a hardcap. Deputy Moore’s federal testimony is not Scott’s personal endorsement.

AI is separate: primary EO04-26 creates economic/adoption advisory taskforce; October reporting favors federal safety regulation. Neither proves physical buildout support. Own DC-specific incentive pledge, quantitative water limit and detailed tariff commitment remain unknown.

Primary governor host403; signed veto recovered from Housejournal and executive order from legislature host. AP originalwire body read on Chronicle, directAP inaccessible; host Nov3 header conflicts with WednesdayNov4 body/call. Syndicated September16 article is older September9 original, not a new event. No video watched, no invented page access. No causal capacity or delay estimates.

See sources.jsonl for exact locators and limitations, records.jsonl for distinctions, search-log.jsonl for scope. timing.json and checkpoint.json preserve real active segments and excluded recovery gap. Submission does not signify review acceptance.
