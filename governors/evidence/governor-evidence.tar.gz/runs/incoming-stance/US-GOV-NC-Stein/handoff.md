# US-GOV-NC Josh Stein — candidate submission

Verified holdover: NGA Jan1 2025current tenure plus constitutional four-year cycle; Nov4current activity corroborates. No2026gubernatorial winner asserted. Correct office Governor; separately counted governor seat.

Physical stance is conditional/mixed. Own2025remarks welcomed Amazon’s planned Richmond County physical campus. April2026asked repeal-or-modify tax review; June broader phaseout was a proposal. July7signed SB257/SL2026-41: section44.4 actually repeals electricity exemptions for both qualifying categories, effective on becoming law for electricity both billed and sold thereafter; equipment/property exemptions remain. The full2032sunset is not established as law.

July23requested binding full-cost large-load tariff following Duke’s voluntary federal pledge. Oct14/Oct27asks Commission to require full costs including generation and own clean power. Duke proposal was pending, not an approved final tariff in retrieved sources. Forecasts cited by office are conditional modeling, not observed causal effects or new capacity estimates.

Contrary evidence includes Amazon/industry investment-certainty objections, April taskforce scope/cost-benefit reservations, and NCWARN call for statewide freeze. None establishes Stein’s adoption of a moratorium. Own statewide freeze position and quantitative campus water ceiling not located. EO24water/energy concern and taskforce reporting exploration do not create a binding water limit. AIroadmap kept separate from physical buildout.

Predecessor Cooper’s original2018welcome covered Corvid mixed headquarters/HPCcampus, with conditional JDIG; do not treat all367jobs or grant as data-center-only, or2026Senate campaign as governor-period evidence. Historical narrow comparison, no identical-facility causal inference.

Context: DEQ issued Richmond air permits; SELC challenged their separation. No personal Stein permit action established. Agency588backup versus litigant592backupengine counts conflict; outcomes and underlying permits/petitions unretrieved. Separate authorities and allegations retained.

All records remain candidate for reviewer_runner_2. Raw HTML/PDF text inspected; no audio/video/image observation claimed. NoSemiAnalysis or GWdelay work. Timing excludes context gap conservatively.
