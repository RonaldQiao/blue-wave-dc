# US-GOV-ND — Kelly Armstrong

Candidate research only; independent review required. Governor of North Dakota, a holdover after the2026 midterms. Term began December15 2024; NGA current roster and2024 four-year calendar agree. No fictitious2026 governor election call. Doug Burgum is predecessor, and his views remain separate.

Armstrong supports physical development under conditions: praised Ellendale expansion and associated housing, signed HB1539 narrowing PSC siting treatment of isolated emergency backup, and describes opportunities for willing communities while rejecting resident electricity-cost shifts. The direct edited interview, May television interview and August/September radio summaries preserve local choice, power/water-resource rules and skepticism about industry-specific carveouts.

Material contrary detail: September1 testimony opposed SB2406 additional NDA enforcement despite transparency rhetoric, citing existing open-records protections and confidentiality concerns. Senate subsequently defeated it15–32; no gubernatorial veto or legislative vote. July RGA pledge is voluntary and expressly qualified by governors’ authority, not a binding tariff or observed consumer outcome. The June committee was legislators’ creation, which he welcomed.

Primary legal audit resolves date-entry ambiguity: detailed HB1539 actions and governor communication in March21 journal specify March19 signature; HB1167 actions and April11 journal specify April10 signature. Bill-overview summary dates alone are misleading. Read enrolled texts; unsigned enrollment-template signature blocks are not execution proof. HB1539 excludes non-grid-interconnected temporary backup from Siting Act scope, without eliminating local/environmental approvals. AI political-impersonation disclosure law is kept separate from physical siting.

Unknowns: no attributable broad statewide moratorium position, DC-tax-repeal stance or quantified water cap located. Legislative leaders’ agenda decisions, Mathern’s repeal proposal, Kroshus’ tax presentation and agency water-adequacy remarks cannot substitute. Tax exemption history predates this tenure. Linked radio audio was not reviewed; station articles were. Search failures include KFGO403, JackFM404, original Aug17 Monitor403 (syndicated body available), and failed guessed legislative paths later recovered through real links.

17records,29sources,14search logs. Exact interview days remain unknown where publication did not establish them. No capacity/delay inference or selfapproval. See timing.json for clock-verified active segments and excluded recovery interval; minimum met with 316.230 active seconds.

Additional secondary-claim check: SB2280 enrolled text requires licensed clinical personnel in adverse prior-authorization decisions, without expressly naming AI. Recorded as healthcare scope context, without converting it to a broad technology stance.
