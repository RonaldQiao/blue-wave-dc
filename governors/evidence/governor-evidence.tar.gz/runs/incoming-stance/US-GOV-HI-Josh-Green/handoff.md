# Candidate handoff: US-GOV-HI / Josh Green
Governor of Hawaii; HI; district null. Candidate only, requires independent review.

Original HPR Nov3 8:08PMHST report attributes reelection to AP. Gary Cordery defeated; Derek Kawakami is lieutenant governor. Certification and exact next inauguration unverified; do not apply mainland January2027 term template.

Strong physical evidence: formal signed June29 2023 GM1233 objects to4m state data-center relocation planning and50m first-responder campus funding. Jun14 announcement retains1m relocation planning. Fiscal/planning/permit timing rationale is project-specific, not blanket private-hyperscale opposition. No current broad private-DC position located.

HCR206 HD1 adoptedApr27 2026 is legislative study resolution, no gubernatorial signature. HSEO study options are not adopted tariff or state ban. Testimony bundle contains PUC and Mark Glick; Governor letterhead is not his testimony. County Bill170 belongs Heather Kimball. Western conference attendance/silence not individual stance; cooling quote is Burgum. AI Acts247/248 signedJuly14 separately verified by original messages.

Agency working-group deadline parentheticalDecember31 2027 contradicts own text and original resolution; original says20days before2027session. Final2023enactment/currentappropriation and county subsequentstatus unresolved. Unknown not neutral. Timing separately excludes compaction interval.

Additional contrary evidence: Act173/SB2526 approvedJuly2 2024 supports state critical-system inventory and resilient/redundant hosting. Adjacent veto snippet from multi-bill index was false attribution. SB338 tax-credit endorsement belongs Servpac CEO; DOTAX testimony belongs Suganuma. SB1111 resource-opposition quote belongs Food+ team. General own July2026 questionnaire energy/LNG/renewables response separate.

Candidate QA checks28sources/12records, references resolve, correctGovernor office/districtnull, quotes within25words/source. SignedGM1274 inaccessible; official published Act173 and archivedstatus establish approval. Agency2025packet p33 confirms expected2026decommissioning, not actualcompletion. Searchlog distinguishes reconstructed scope families from exact retainedquery strings.

Office of Elections originaltermrule verified: next statutory start firstMondayDecember, calendar-derivedDec7 2026noon HST; ceremony stillunverified. Final29sources/12records. Active research 322.694126seconds, conservative compaction exclusion in timing.json.
