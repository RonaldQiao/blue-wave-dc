# US-GOV-WV — Patrick Morrisey

Candidate packet for independent review; Governor office, separate from House and Senate denominators. Verified actual holdover in current four-year term starting January13 2025 using current NGA/official biography, NGA2024winner calendar and constitutional tenure. No2026election winner or certification claimed.

Strong direct support for physical data-center development: requested/signed HB2014/2002; named-project approvals and public recruitment; August2026 framework. Preserve stated resource/ratepayer protections alongside local preemption and unresolved enforceability. No federal rollcall or general-AI-only inference.

Primary law distinguishes certified90MWaggregate criticalIT projects, microgrid cost protections and continuing environmental requirements. HB4983history describes approvalMarch27, table entryMarch30; final rule effectiveApril1. Confidential petitions, discretionary information requests and extendible decisions limit transparency. The long-term plan recruits water-efficient cooling; universal mandatory cooling/withdrawal cap not established. Advisory council final appointments unverified. Administration counsel and PSC actions remain context, not personal orders.

Latest verified own physical statement October10: developer-funded tree relocation promised for late2027; completion and survival unverified. October12reproduction includes ecological objection. November3MetroNews original inaccessible twice; search extract clearly attributes favorable bill quote to strategist GregThomas, excluded from Morrisey stance. No audio, images or video reviewed.

Same governor continues after2026; JimJustice is historical pre2025 predecessor, not outgoing2026 replacement. Actual project investments/jobs/energization and later binding safeguards remain unverified. Unknown is not neutral. All records candidate pending independent review.
