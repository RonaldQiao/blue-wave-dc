# US unfinished data-center inventory

## Interim research report — 8 November 2026

Reviewed-data snapshot: 2026-11-08T20:30:49.473471+00:00. Individual evidence dates are shown separately below. This is a report of the reviewed evidence, not an exhaustive national census or a fresh observation of work on the report date.

## Executive summary

- The reviewed inventory contains **19 accepted unfinished facility/phase records across 11 states**. These are records, not a certified count of distinct facilities or the complete US construction pipeline.

- Preliminary discovery and independent review cover **50 states plus DC**. Full municipal/project coverage remains incomplete. The absence of queued work is not research completion.

- **16 of the 19 accepted records have no quantified remaining unfinished MW.** Two records identify 63 MW in total on a critical-IT basis; a third identifies 5 MW of IT commissioning capacity. These are partial, source-dated scopes, not a national backlog total.

- Whole-facility design and campus ambitions must stay separate from unfinished increments. Texas is represented by five accepted records, including large individually specified designs at Milam and Beacon Point; this does not establish a national ranking of state backlogs.

## Most reviewed records remain qualified

Every row below has a review disposition. “Qualified” means the evidence or scope does not yet justify unconditional inclusion; it does not mean the submission is awaiting its first independent review. The classification counts may include different phases or related records at a campus.

| Review disposition | Records |
| --- | --- |
| Accepted unfinished | 19 |
| Qualified | 1066 |
| On hold | 11 |
| Excluded | 98 |
| Completed | 4 |
| Total | 1198 |

![Classification of reviewed inventory records](record-classification.png)

These counts describe this research inventory. They are not facility-market shares, MW shares, national coverage rates or a measurement of the materiality of sub-20 MW exclusions.

## Accepted unfinished records

The >20 MW cutoff applies to verified facility size. The separate unfinished-increment column is the only capacity shown here as unfinished work. “Unallocated” is unknown, not zero. All facility figures below are design statements with the basis shown; they are not a measure of operating capacity.

Accepted status is tied to the recorded source observation. Dated status snapshots range from September 21 to November 6, 2026; other sources use relative or undated descriptions. A November 8 retrieval or audit is not a November 8 construction event. Company names identify recorded developers/operators, not a blanket verification of current property title.

| Facility / phase record | State / county | Developer | Facility design MW / basis | Unfinished increment | Status snapshot / period |
| --- | --- | --- | --- | --- | --- |
| DigiPowerX Columbiana, Phase 1 | AL / Shelby | Digi Power X | 40 — IT design | Unallocated | 2026-10-13 |
| Serverfarm ARK1 | AR / Johnson | Serverfarm | 108 — Design MW; IT/electrical basis unspecified | Unallocated | 2026-10-30 |
| Core Scientific Dalton 4 / Phase 2 | GA / Whitfield | Core Scientific | 145 — Critical IT design | Unallocated | Operator post displays2w; exact post/edit/event day unknown |
| WhiteFiber NC1, remaining commissioning | NC / Rockingham | WhiteFiber / Enovum | 40 — IT design | 5 MW | 2026-11-03 |
| Polaris Forge 1, third HPC building | ND / Dickey | Applied Digital | 150 — Critical IT design | Unallocated | 2026-10-07 |
| Polaris Forge 2, Building 1 | ND / Cass | Applied Digital | 150 — Critical IT design | Unallocated | 2026-10-07 |
| Polaris Forge 2, Building 2 | ND / Cass | Applied Digital | 150 — Critical IT design | Unallocated | 2026-10-07 |
| Lake Mariner CB4 | NY / Niagara | TeraWulf | 168 — Critical IT design | Unallocated | 2026-11-06 |
| Lake Mariner CB5 | NY / Niagara | TeraWulf | 168 — Critical IT design | Unallocated | 2026-11-06 |
| Core Scientific Muskogee, second building | OK / Muskogee | Core Scientific | 82.5 — Design MW; IT/electrical basis unspecified | Unallocated | Original post displays1w; exact publication/event day unknown |
| Cipher Barber Lake | TX / Mitchell | Cipher Digital Inc. | 168 — Historical critical IT design; amended maximum unknown | Unallocated | 2026-11-02 |
| Hut 8 Beacon Point, Phase 1 building | TX / Nueces | Hut 8 Corp. | 352 — Critical IT design | Unallocated | 2026-11-04 |
| Riot Rockdale AMD, Phase 4 | TX / Milam | Riot Platforms | 50 — Critical IT design | 15 MW | 2026-11-04 |
| SB Energy Milam, Building 1 | TX / Milam | SB Energy | 308 — Critical IT design | Unallocated | 2026-09-21 |
| SB Energy Milam, Building 2 | TX / Milam | SB Energy | 445 — Critical IT design | Unallocated | 2026-09-21 |
| DataBank IAD5 | VA / Culpeper | DataBank | 72 — Critical IT design | Unallocated | Original operator post1moEdited; contractor post4mo; exact calendar/edit/event dates unknown |
| Iron Mountain RCH1 | VA / Henrico | Iron Mountain | 48 — Critical IT design | 48 MW | 2026-09-30 |
| Vantage Lighthouse WI12 | WI / Ozaukee | Vantage Data Centers | 202 — Design MW; IT/electrical basis unspecified | Unallocated | October–November summary; no exact publication/work day |
| Related Digital Cheyenne, first phase | WY / Laramie | Related Digital | 88 — Critical IT design | Unallocated | Original post1moEdited; exact calendar/edit/event day unknown |

## Texas is present, but state backlogs cannot be ranked reliably

Texas contributes five accepted records in this snapshot: SB Energy Milam Buildings 1 and 2, Hut 8 Beacon Point’s Phase 1 building, Riot’s Rockdale AMD Phase 4, and Cipher Barber Lake. The individually specified critical-IT designs include 445 MW at Milam Building 2, 352 MW at Beacon Point and 308 MW at Milam Building 1. None of those three figures is a quantified remaining increment.

Other large Texas leads, including Helios, IREN Childress, Goodnight, Black Pearl and Stingray, remain qualified where individual-building scope or current unfinished allocation is unresolved. Their campus or contract totals must not be inserted into a state active-IT-MW ranking.

## Only three records quantify an unfinished increment

| Basis | Source-dated unfinished scope | Records / source snapshot |
| --- | --- | --- |
| Critical IT load | 63 MW | RCH1: 48 MW as of 2026-09-30; Riot Rockdale: 15 MW as of 2026-11-04 |
| IT commissioning increment | 5 MW | WhiteFiber NC1 as of 2026-11-03 |
| Other accepted records | Unallocated | 16 records; no remaining-MW sum |

The 63 MW is 48 + 15 from the two named source-qualified scopes. The 5 MW commissioning increment stays separately labelled. These figures do not measure the national pipeline, the physical work remaining today, or the capacity of all accepted facilities. In particular, a 40 MW facility with 5 MW of unfinished commissioning remains in scope without counting all 40 MW as unfinished.

## Important large construction leads remain qualified

The following are priority gaps, not additional accepted facilities. The full reviewed dataset and retained coverage/gap notes are supplied in the accompanying data files. A physical construction statement at campus level does not by itself establish the size or unfinished scope of an individual building.

| Project / state | Unresolved inclusion question |
| --- | --- |
| River Bend / LA | Individual host-building and four-hall allocation; original engineering/physical-premises schedule. Incentive approval is fiscal evidence, not construction. |
| Project Jupiter / NM | First 855,000 sq ft portion to numbered building crosswalk and original building electrical design; no area-to-MW conversion. |
| Polaris Forge 3 / ND | Explicit load and scope of each physical building; no division of a 300 MW two-building total. |
| Helios Phase II / TX | Separate original HEL03/HEL04 design/lease basis; 260 MW across two buildings does not prove 130 MW each. |
| IREN Childress Horizons 2–4 / TX | Physical-building identity and load; deployment tranches and unviewed stage matrices are not building allocations. |
| Goodnight / TX and Lyle Creek / NC | Current individual design, phase identity and remaining work; clean campus/first-building progress alone does not resolve all gates. |
| Black Pearl and Stingray / TX | Contractual facility/campus to physical building crosswalk; campus or contract IT capacity is not automatically one building. |
| Lighthouse WI11/WI13/WI14 / WI | Individual electrical/IT design and latest inspections; no combined-capacity split. WI12 remains separately accepted. |
| QTS Eagle Mountain / UT | Numbered-building design and first-versus-third topping-out crosswalk. |
| QTS York / SC | Historical utility/campus crosswalk is now supported, but demand is redacted and individual building capacity/work remain unallocated. |

## Permit-backed planning stays separate

**98 records** occupy the permit-backed-planning lane. They are a subset of the reviewed inventory, not 98 independently established >20 MW facilities under construction. Original permit applications or authorizations do not establish that physical work has begun. The complete lane is in [permit-backed-planning.csv](permit-backed-planning.csv); unknown capacity and scope remain explicit.

## What the latest deepening established

The latest five source-family audits added provenance rather than accepted MW. York’s original engineering and utility documents establish a historical QTS Allison Creek campus / QTS York Infrastructure I LLC service crosswalk, with redacted demand and no individual-building allocation or property-ownership conclusion. Lighthouse’s new contractor caption is recruitment context. Jupiter’s report body remains inaccessible or unidentified; River Bend’s public application records are fiscal, with a detailed packet offered through a stated email-request route; no public technical attachment was recovered in the bounded pass; PF3’s public navigation did not expose the named technical appendices. No contact request was sent. All five audits were independently reviewed without changing the 19 accepted records.

## Coverage, ownership and freshness limits

- All 51 preliminary state/DC packets are independently reviewed, but their municipal/project coverage is incomplete. The state-by-state record counts and remaining coverage limits are in [state-coverage.csv](state-coverage.csv). A state with no accepted record is not a state with no construction.

- Developer, operator, tenant, applicant and project LLC are different roles. The detailed profiles preserve their recorded labels. A project company or utility customer is not necessarily the current deed owner; unknown ownership is not filled by inference.

- Source dates, performed-work dates, reporting-period dates and retrieval dates differ. The accepted profiles retain these distinctions. Completion forecasts, blank final fields and a failure to find a completion notice are not positive proof of unfinished construction.

- Operational buildings and delivered phases are not added to unfinished capacity. Roads, substations, backup generators, kV/MVA ratings and campus ambitions are not substituted for active IT MW.

- The materiality of sub-20 MW facilities remains **unquantified** without a matched primary denominator. No exclusion share is claimed.

- Source-identifier closure is complete for the 19 accepted records in this export, but closure alone is not fact validation. The report inherits the independent review qualifications and preserves the source index and raw-capture hashes.

## Research completion and hourly automation

The preliminary nationwide discovery stage is complete; the full unfinished-facility inventory is not. Zero pending submissions and 51 reviewed jurisdictions do not resolve unsearched municipal records, individual-facility size, current phase allocation or inaccessible originals. The recorded hourly construction dispatcher remains enabled because the user’s completion condition has not been met. The completed politician-stance research and its disabled automation were not changed.

The report uses the reviewed export from 20:30 UTC on November 8. The existing private dashboard’s local saved snapshot was refreshed at 20:32 UTC; its hosted version remains the 01:16 UTC saved snapshot because source publication and continuous uploads remain blocked. Neither is presented as a live feed.

## Work required before a scoped final inventory

Prioritize original building-specific design or service schedules for the major held construction leads; join them to dated building work and the correct parcels or jurisdictions. Obtain newer numbered-building completion/occupancy or equivalent current issuer evidence where the accepted source vintage is older. Reconcile phases and aliases without summing parent and child capacity. Extend municipal coverage beyond the preliminary packets and retain a final, explicit disposition for every material unresolved lead or irreducible access limit. These gaps prevent a defensible national MW total or exhaustive state-backlog ranking.

## Accepted-record evidence profiles

### DigiPowerX Columbiana, Phase 1

**Location:** Shelby County, AL. Municipality/locality: Columbiana.

**Companies:** Developer: Digi Power X. Operator/tenant role as recorded: Digi Power X. Recorded project entity: Not recorded. This is not a title opinion.

**Facility design:** 40 MW; IT load. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** 2026-10-13. The issuer reported construction on schedule on October 13. July shell erection is separately supported; a later detailed MEP claim was not recovered as an original capture. Remaining MW is unallocated.

- Facility scope/design: [original source](https://www.sec.gov/Archives/edgar/data/1854368/000121390026053566/ea028958501ex10-1.htm); Summary73-75,Article1line160,Article2.2lines250-252. Source ID: `AL-24960e2ac9f2c8fda642d942-source-001`.

- Facility scope/design: [original source](https://www.sec.gov/Archives/edgar/data/1854368/000121390026089940/ea0301731-10q_digipower.htm); note20 lines1428-29; MD&A1571. Source ID: `AL-2068a6c9e210a3775e65121a-source-002`.

- Work/status: [original source](https://www.nasdaq.com/press-release/digi-power-x-announces-200-million-debt-financing-commitment-support-completion); Original Nasdaq response L9,13–21; not preceding search snippets.

- Work/status: [original source](https://www.sec.gov/Archives/edgar/data/1854368/000121390026075755/ea029720301ex99-1.htm); Original SEC response L22/31 shell erection at July7 publication.

**Source qualification:** July7 shell is a historical performed stage, exact work day unknown. October13 does not specify a newer physical substage. Later detailed MEP caption is reported in prior bounded analyst notes; no retained actual caption payload located. Do not present that as an independently recovered current MEP stage.

Record `AL-digipower-columbiana-phase1`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### Serverfarm ARK1

**Location:** Johnson County, AR. Municipality/locality: Clarksville.

**Companies:** Developer: Serverfarm. Operator/tenant role as recorded: Serverfarm. Recorded project entity: SF ARK1 LLC (citypacketprojectcompany;notcurrentparceltitleverification). This is not a title opinion.

**Facility design:** 108 MW; developer individual Building Capacity MW; IT versus total electrical unspecified. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** 2026-10-30. The October 30 developer account describes the October 7 final beam and continuing construction. The 108 MW figure is an individual-building design statement with an unspecified IT-versus-electrical basis.

- Facility scope/design: [original source](https://www.serverfarmllc.com/arkansas/); ARK1lines161-183;FAQ494-500. Source ID: `AR-139e607ffee97f5971d77856-source-002`.

- Work/status: [original source](https://www.serverfarmllc.com/blog/building-for-the-future-serverfarm-celebrates-clarksville-construction-milestone/); Original Serverfarm response L115–129.

**Source qualification:** Publication October30, topout event October7; neither November7 re-reading nor November8 audit is a new milestone. Supplier electrical narrative is campus-wide/undated and not a newer ARK1 inspection.

Record `AR-serverfarm-ark1`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### Core Scientific Dalton 4 / Phase 2

**Location:** Whitfield County, GA. Municipality/locality: Not recorded.

**Companies:** Developer: Core Scientific. Operator/tenant role as recorded: Not recorded. Recorded project entity: Core Scientific Dalton LLC. This is not a title opinion.

**Facility design:** 145 MW; critical IT load. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** Operator post displays2w; exact post/edit/event day unknown. The operator describes Phase 2 as still being built amid partial deliveries. The post carries a relative date. Campus totals and billable deliveries cannot be subtracted to produce remaining building capacity.

- Facility scope/design: [original source](https://investors.corescientific.com/sec-filings/all-sec-filings/content/0001193125-26-165121/d149019dex992.htm); DaltonCampuses lines116-138 andcapacitytable. Source ID: `GA-deep-5f775a2e-source-001`.

- Work/status: [original source](https://www.linkedin.com/company/corescientific); Original L118–131.

**Source qualification:** New actual original recovery is a November8 retrieval vintage, not November8 physical work. Phase2/Dalton4 identity uses existing separately reviewed original design; no175minus75 or48MW delivery arithmetic for remaining capacity.

Record `ga-core-scientific-dalton4`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### WhiteFiber NC1, remaining commissioning

**Location:** Rockingham County, NC. Municipality/locality: Madison.

**Companies:** Developer: WhiteFiber / Enovum. Operator/tenant role as recorded: WhiteFiber. Recorded project entity: Enovum NC-1 Bidco LLC (county project entity; current title not independentlyrechecked). This is not a title opinion.

**Facility design:** 40 MW; IT load. **Unfinished increment:** 5 MW; IT commissioning increment

**Status observation:** 2026-11-03. The November 3 issuer release states that 35 MW of the initial 40 MW deployment is operational and work continues to bring the remaining 5 MW online. Commissioning is separate from completed initial capital work.

- Facility scope/design: [original source](https://www.sec.gov/Archives/edgar/data/2042022/000121390026115575/ea031063901ex99-1.htm); lines18–20,29. Source ID: `NC1-deep-001`.

- Facility scope/design: [original source](https://investor.unifi.com/static-files/1b52bf2d-cd29-42e1-8021-12325e6ae330); PDFpage4 lines80–90. Source ID: `NC1-deep-003`.

- Work/status: [original source](https://www.sec.gov/Archives/edgar/data/2042022/000121390026115575/ea031063901ex99-1.htm); Original SEC response L7,18–20.

**Source qualification:** Status-as-of release; exact individual repair/testing day unknown. Initial20MW service interruption is not another unfinished increment; substantially complete capex is not complete commissioning.

Record `NC-whitefiber-nc1-remainder`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### Polaris Forge 1, third HPC building

**Location:** Dickey County, ND. Municipality/locality: Ellendale area.

**Companies:** Developer: Applied Digital. Operator/tenant role as recorded: CoreWeave tenant / Applied Digital owner. Recorded project entity: Not recorded. This is not a title opinion.

**Facility design:** 150 MW; critical IT design load. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** 2026-10-07. The October 7 SEC release names the third 150 MW HPC building as under construction. Completed first and second buildings are separate. The 2027 service target is a forecast, not the construction evidence.

- Facility scope/design: [original source](https://www.applieddigital.com/ai-factories); Lines86–93. Source ID: `ND-5fa871-source-002`.

- Work/status: [original source](https://www.sec.gov/Archives/edgar/data/1144879/000114487926000057/apldq127earningsrelease.htm); Original SEC response L49,66,119–121.

**Source qualification:** July roof50percent source is an earlier trade observation. 2027RFS forecast is not positive unfinished proof; third building is affirmatively named as in construction.

Record `ND-pf1-third-hpc`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### Polaris Forge 2, Building 1

**Location:** Cass County, ND. Municipality/locality: Harwood area; jurisdictionboundaryunresolved.

**Companies:** Developer: Applied Digital. Operator/tenant role as recorded: Applied Digital / undisclosedinvestmentgradehyperscalertenant. Recorded project entity: Not recorded. This is not a title opinion.

**Facility design:** 150 MW; critical IT design load. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** 2026-10-07. Dated October 7 campus construction disclosure and undated individually labelled buildings support the accepted scope. The earlier numbered physical stage is separate; no November delivery or remaining MW is verified.

- Facility scope/design: [original source](https://www.applieddigital.com/ai-factories); Lines86–93. Source ID: `ND-5fa871-source-002`.

- Work/status: [original source](https://ir.applieddigital.com/sec-filings/all-sec-filings/content/0001144879-26-000057/apldq127earningsrelease.htm); Bundled actual SEC response L3,47,63–64; separately AI-factories original L88–93.

**Source qualification:** October7 is campus-level unfinished confirmation, not new numbered-building trade. Earlier April caption supplies numbered physical stages. Undated individual labels are affirmative source statements but have no exact status date; same page stale PF1B2 label is overridden by dated SEC completion, so do not infer November freshness for PF2.

Record `ND-pf2-building1`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### Polaris Forge 2, Building 2

**Location:** Cass County, ND. Municipality/locality: Harwood area; jurisdictionboundaryunresolved.

**Companies:** Developer: Applied Digital. Operator/tenant role as recorded: Applied Digital / undisclosedinvestmentgradehyperscalertenant. Recorded project entity: Not recorded. This is not a title opinion.

**Facility design:** 150 MW; critical IT design load. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** 2026-10-07. The second 150 MW building remains separately identified. Earlier electrical/slab progress and the October 7 campus disclosure do not quantify current remaining capacity. PF1 completion cannot be transferred to PF2.

- Facility scope/design: [original source](https://www.applieddigital.com/ai-factories); Lines86–93. Source ID: `ND-5fa871-source-002`.

- Work/status: [original source](https://ir.applieddigital.com/sec-filings/all-sec-filings/content/0001144879-26-000057/apldq127earningsrelease.htm); Bundled actual SEC response L3,47,63–64; separately AI-factories original L88–93.

**Source qualification:** October7 is campus-level unfinished confirmation, not new numbered-building trade. Earlier April caption supplies numbered physical stages. Undated individual labels are affirmative source statements but have no exact status date; same page stale PF1B2 label is overridden by dated SEC completion, so do not infer November freshness for PF2.

Record `ND-pf2-building2`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### Lake Mariner CB4

**Location:** Niagara County, NY. Municipality/locality: Town of Somerset.

**Companies:** Developer: TeraWulf. Operator/tenant role as recorded: Lake Mariner Data LLC. Recorded project entity: Not recorded. This is not a title opinion.

**Facility design:** 168 MW; critical IT load. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** 2026-11-06. The November 6 SEC investor update says CB4 and CB5 construction is advancing. Facility design is distinct from phased deliveries, commercial acceptance and remaining commissioning capacity.

- Facility scope/design: [original source](https://www.sec.gov/Archives/edgar/data/1083301/000162828026071306/terawulfq32026investorpr.htm); See recorded source fields. Source ID: `CB4-deep-002`.

- Work/status: [original source](https://www.sec.gov/Archives/edgar/data/1083301/000162828026071306/terawulfq32026investorpr.htm); Original SEC response L4,27; original issuer release L61 has September30 accounting context.

**Source qualification:** Nov6 is issuer status/report date, not exact hall energization or inspection day. CB4 actual first-hall commissioning by August5 and later reported tenant equipment energization are scoped partial events, not all-building completion. CB5 does not inherit CB4 hall events.

Record `ny-lakemariner-cb4`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### Lake Mariner CB5

**Location:** Niagara County, NY. Municipality/locality: Town of Somerset.

**Companies:** Developer: TeraWulf. Operator/tenant role as recorded: Lake Mariner Data LLC. Recorded project entity: Not recorded. This is not a title opinion.

**Facility design:** 168 MW; critical IT load. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** 2026-11-06. The same November 6 disclosure names CB5 alongside CB4. The two buildings stay separate; reported design capacity is not treated as their remaining unfinished increment.

- Facility scope/design: [original source](https://www.sec.gov/Archives/edgar/data/1083301/000162828026071306/terawulfq32026investorpr.htm); slides7,10,11 lines59,79,86. Source ID: `NY-deep-709879dd-source-001`.

- Work/status: [original source](https://www.sec.gov/Archives/edgar/data/1083301/000162828026071306/terawulfq32026investorpr.htm); Original SEC response L4,27; original issuer release L61 has September30 accounting context.

**Source qualification:** Nov6 is issuer status/report date, not exact hall energization or inspection day. CB4 actual first-hall commissioning by August5 and later reported tenant equipment energization are scoped partial events, not all-building completion. CB5 does not inherit CB4 hall events.

Record `ny-lakemariner-cb5`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### Core Scientific Muskogee, second building

**Location:** Muskogee County, OK. Municipality/locality: Muskogee.

**Companies:** Developer: Core Scientific. Operator/tenant role as recorded: Not recorded. Recorded project entity: Not recorded. This is not a title opinion.

**Facility design:** 82.5 MW; issuer individual-building design MW; IT versus total electrical unspecified. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** Original post displays1w; exact publication/event day unknown. The operator post describes advancing construction and vertical walls in the initial hall of the second building. Its relative date does not establish an exact work day. The 82.5 MW design basis is unspecified.

- Facility scope/design: [original source](https://investors.corescientific.com/news-events/press-releases/detail/135/core-scientific-plans-expansion-to-1-5-gigawatts-of-gross-power-at-muskogee-oklahoma-campus); Line51. Source ID: `OK-5d2b6a-source-004`.

- Work/status: [original source](https://www.linkedin.com/company/corescientific); Original L89–91.

**Source qualification:** New actual original recovery is November8 retrieval, not an accomplished November8 event. First completed building and future2H2027 delivery separate; no remainingMW from82MW design.

Record `OK-core-muskogee-second`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### Cipher Barber Lake

**Location:** Mitchell County, TX. Municipality/locality: Colorado City (creditagreement location; municipalboundary not independentlymapped).

**Companies:** Developer: Cipher Digital Inc.. Operator/tenant role as recorded: Cipher Digital Inc. / Cipher Barber Lake LLC. Recorded project entity: Cipher Barber Lake LLC. This is not a title opinion.

**Facility design:** 168 MW; critical IT load; original historical design, not current amended maximum. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** 2026-11-02. The November 2 issuer update affirms continuing construction against amended hall milestones. Earlier topping-out and MEP evidence is retained. The original 168 MW design is historical; neither the amended maximum nor remaining MW is inferred.

- Facility scope/design: [original source](https://www.sec.gov/Archives/edgar/data/1819989/000095010326004609/dp244113_ex1001.htm); L8,20 execution/date;L437–438 building/location. Source ID: `TX-BARBER-source-001`.

- Facility scope/design: [original source](https://www.sec.gov/Archives/edgar/data/1819989/000181998925000112/cifr-20250930.htm); L1438–1439. Source ID: `TX-BARBER-source-002`.

- Work/status: [original source](https://www.sec.gov/Archives/edgar/data/1819989/000181998926000025/exh991q1fy26_earningsxprvf.htm); L11,18.

- Work/status: [original source](https://investors.cipherdigital.com/news-releases/news-release-details/cipher-digital-provides-third-quarter-2026-business-update); L28,37–39,46,53.

**Source qualification:** 168criticalIT is original historical facilitydesign,not currentamendedmaximum. 300gross/site and685acfutureexpansion notunfinishedcapacity.

Record `TX-cipher-barberlake-unallocated`; independent review `2026-11-08T050338607175+0000-bf9ca8b9`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### Hut 8 Beacon Point, Phase 1 building

**Location:** Nueces County, TX. Municipality/locality: Not recorded.

**Companies:** Developer: Hut 8 Corp.. Operator/tenant role as recorded: Not recorded. Recorded project entity: Beacon Point DC LLC. This is not a title opinion.

**Facility design:** 352 MW; Original explicit single Phase1 building designed critical IT capacity. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** 2026-11-04. The November 4 release reports Q3 foundation and underground utility work and construction on track. The original 352 MW design refers to one Phase 1 building; Phase 2 civil design does not prove a second building has started.

- Facility scope/design: [original source](https://www.sec.gov/Archives/edgar/data/1964789/000119312526446146/hut-20260930.htm); L1370–1375. Source ID: `REVIEW-20261107-beacon-independent-originals-0c94d3ca`.

- Facility scope/design: [original source](https://cdn.sanity.io/files/2iccs2ie/production/62cc856839f56613548f3bd3fe5d21de8bbb6c4c.pdf); 14pPDFP8L244–269,P11L346–353;29pissuertranscriptP18L669–678. Source ID: `REVIEW-Beacon-single-building-design-saved`.

- Work/status: [original source](https://www.prnewswire.com/news-releases/hut-8-reports-third-quarter-2026-results-302928583.html); Original L453–457,477,491.

**Source qualification:** Performed trade interval is Q3 July1–September30, exact day unknown; November4 is status report, not field inspection. Phase2 civil design/contract finance utility category does not prove its DC building started.

Record `TX-hut8-beaconpoint-phase1-building`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### Riot Rockdale AMD, Phase 4

**Location:** Milam County, TX. Municipality/locality: Not recorded.

**Companies:** Developer: Riot Platforms. Operator/tenant role as recorded: Riot Platforms. Recorded project entity: Riot Platforms/RiotRockdaleentities; exactbuildingdeedLLCunverified. This is not a title opinion.

**Facility design:** 50 MW; Approximate single AMD retrofit-building criticalIT design in original issuer text/contract context. **Unfinished increment:** 15 MW; critical IT load

**Status observation:** 2026-11-04. The November 4 SEC text identifies 15 MW of remaining cooling-distribution installation and electrical testing in an approximately 50 MW AMD retrofit building. Separate delivered capacity and unrelated permit closure are not added to that increment.

- Facility scope/design: [original source](https://www.sec.gov/Archives/edgar/data/1167419/000110465926122368/riot-ex99d2.htm); L4,36–43,63,69. Source ID: `REVIEW-20261107-riot-independent-originals-9c9356bc`.

- Facility scope/design: [original source](https://www.riotplatforms.com/riot-announces-fee-simple-acquisition-of-land-and-first-data-center-lease-with-amd-at-the-rockdale-site/); L29,36–44. Source ID: `REVIEW-20261107-riot-independent-scope-3223ad4c`.

- Work/status: [original source](https://www.sec.gov/Archives/edgar/data/1167419/000110465926122368/riot-ex99d2.htm); Original L4,36–37.

**Source qualification:** November4 is source status date, exact trade day unknown. Initial25MW completed and separate10MW energization/commissioning timeline ambiguity preserved; no arithmetic additional remaining load.

Record `TX-riot-rockdale-amd-phase4-15mw`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### SB Energy Milam, Building 1

**Location:** Milam County, TX. Municipality/locality: Not recorded.

**Companies:** Developer: SB Energy. Operator/tenant role as recorded: Not recorded. Recorded project entity: Milam County DC, LLC. This is not a title opinion.

**Facility design:** 308 MW; Original SEC explicit individual building designed critical IT capacity, not current operating or remaining unfinished MW. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** 2026-09-21. The September 21 prospectus names Building 1 in vertical construction and specifies 308 MW critical-IT design. Later campus corroboration does not provide a newer numbered-building inspection or remaining-MW allocation.

- Facility scope/design: [original source](https://www.sec.gov/Archives/edgar/data/2133037/000162828026062846/sbenergy-sx1a2.htm); L16768–16820;L20569–20578. Source ID: `REVIEW-20261107-milam-independent-originals-3a8ccdf5`.

- Work/status: [original source](https://www.sec.gov/Archives/edgar/data/2133037/000162828026062846/sbenergy-sx1a2.htm); L16768–16800, numbered table16781–16782.

- Work/status: [original source](https://www.sec.gov/Archives/edgar/data/2133037/000162828026062846/sbenergy-sx1a2.htm); L4 filing and L92 prospectus date.

**Source qualification:** April NTP is authorization, not actual physicalstart day. October2 crew/undated first-phase site text is later campus corroboration, not a new numbered-building stage.

Record `TX-sb-energy-milam-building-1`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### SB Energy Milam, Building 2

**Location:** Milam County, TX. Municipality/locality: Not recorded.

**Companies:** Developer: SB Energy. Operator/tenant role as recorded: Not recorded. Recorded project entity: Milam County DC, LLC. This is not a title opinion.

**Facility design:** 445 MW; Original SEC explicit individual building designed critical IT capacity, not current operating or remaining unfinished MW. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** 2026-09-21. The prospectus separately lists Building 2 in vertical construction at 445 MW critical-IT design. Remaining MW is unknown. Draft certificates and future service targets are not actual completion events.

- Facility scope/design: [original source](https://www.sec.gov/Archives/edgar/data/2133037/000162828026062846/sbenergy-sx1a2.htm); L16768–16820;L20569–20578. Source ID: `REVIEW-20261107-milam-independent-originals-3a8ccdf5`.

- Work/status: [original source](https://www.sec.gov/Archives/edgar/data/2133037/000162828026062846/sbenergy-sx1a2.htm); L16768–16800, numbered table16781–16782.

- Work/status: [original source](https://www.sec.gov/Archives/edgar/data/2133037/000162828026062846/sbenergy-sx1a2.htm); L4 filing and L92 prospectus date.

**Source qualification:** April NTP is authorization, not actual physicalstart day. October2 crew/undated first-phase site text is later campus corroboration, not a new numbered-building stage.

Record `TX-sb-energy-milam-building-2`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### DataBank IAD5

**Location:** Culpeper County, VA. Municipality/locality: Not recorded.

**Companies:** Developer: DataBank. Operator/tenant role as recorded: DataBank. Recorded project entity: Not recorded. This is not a title opinion.

**Facility design:** 72 MW; critical IT load. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** Original operator post1moEdited; contractor post4mo; exact calendar/edit/event dates unknown. The operator says construction continues at the first IAD5 main facility, with a contractor topping-out account as corroboration. Relative post/edit dates and the 72 MW whole-building design do not resolve remaining capacity.

- Facility scope/design: [original source](https://www.databank.com/data-centers/northern-virginia/culpeper-campus/iad5/); lines327-351. Source ID: `VA-IAD5-3aa0cffe-source-001`.

- Work/status: [original source](https://www.linkedin.com/posts/databank_datacenters-digitalinfrastructure-construction-activity-7503830447563550720-DtSW); Original operator L21–23 and separate contractor L21–24.

- Work/status: [original source](https://www.databank.com/data-centers/northern-virginia/); Original regional page L336.

**Source qualification:** New actual response recovery does not prove November8 performed work. Undated regional under-construction wording is an affirmative publisher statement, not a dated inspection or no-found-completion inference.

Record `va-databank-culpeper-iad5`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### Iron Mountain RCH1

**Location:** Henrico County, VA. Municipality/locality: Sandston (postal locality).

**Companies:** Developer: Iron Mountain. Operator/tenant role as recorded: Iron Mountain. Recorded project entity: Not recorded. This is not a title opinion.

**Facility design:** 48 MW; critical IT load. **Unfinished increment:** 48 MW; critical IT load

**Status observation:** 2026-09-30. The Q3 table lists 48 MW under construction as of September 30 and was published November 5. That reporting-period date is retained; it is not a November 8 field inspection.

- Facility scope/design: [original source](https://www.ironmountain.com/data-centers/locations/na/richmond/rch-1); lines474–475,522,545,613. Source ID: `VA-d0f2-source-003`.

- Work/status: [original source](https://www.sec.gov/Archives/edgar/data/1020569/000102056926000081/q32026srpfinal.htm); Original printed23 L172–173.

- Work/status: [original source](https://www.sec.gov/Archives/edgar/data/1020569/000102056926000081/q32026srpfinal.htm); Original L11 period end, L18 November5 publication.

**Source qualification:** September30 is a financial reporting snapshot, not exact performed slab/MEP day. August24 contractor publication reports accomplished precast/slab context separately; Q12028 completion forecast not positive proof.

Record `va-ironmountain-richmond-rch1`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### Vantage Lighthouse WI12

**Location:** Ozaukee County, WI. Municipality/locality: Port Washington.

**Companies:** Developer: Vantage Data Centers. Operator/tenant role as recorded: Vantage Data Centers. Recorded project entity: Not recorded. This is not a title opinion.

**Facility design:** 202 MW; contractor individual facility design MW; IT versus total electrical unspecified. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** October–November summary; no exact publication/work day. The October–November project summary describes all four buildings in interior or framework construction. The individual 202 MW design remains basis-qualified; no share of a campus total is assigned to remaining work.

- Facility scope/design: [original source](https://www.weitz.com/weitz-projects-that-shaped-2025/); See recorded source fields. Source ID: `WI-fee0-source-001`.

- Work/status: [original source](https://www.lighthousewisconsin.com/construction-updates/); Original Lighthouse response L24,40–45.

**Source qualification:** WI12 exact stage is not assigned by exhaustive four-building summary. Specific earlier WI12 panels installed is a separate relative-age caption; retrieval date is not work day.

Record `wi-vantage-lighthouse-wi12`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

### Related Digital Cheyenne, first phase

**Location:** Laramie County, WY. Municipality/locality: Cheyenne.

**Companies:** Developer: Related Digital. Operator/tenant role as recorded: Related Digital. Recorded project entity: Campstool Land CO (Oct20,2025 siteplanowner; currentfeeownershipnotverified). This is not a title opinion.

**Facility design:** 88 MW; critical IT load. **Unfinished increment:** Unallocated; remaining capacity is not quantified.

**Status observation:** Original post1moEdited; exact calendar/edit/event day unknown. The operator reports Phase 1 commissioning and first-hall equipment energization in a relative-dated post. That does not establish full IT delivery, complete occupancy or a quantified remaining increment.

- Facility scope/design: [original source](https://www.related-digital.com/wyoming); line29. Source ID: `WY-e46655445b106c8a17f584e6-source-002`.

- Work/status: [original source](https://www.linkedin.com/company/relateddigital/); Original L93–95.

**Source qualification:** New actual original recovery is November8 reading, not November8 work event. Early2027 IT delivery remains forecast; energized equipment is not fullITdelivery/wholeCO or quantified remainingMW.

Record `WY-related-cheyenne-first88`; independent review `2026-11-08T035121716652+0000-641a291c`. Full source IDs, roles, raw locators and qualifications: [accepted-source-index.jsonl](accepted-source-index.jsonl).

## Data and evidence files

- [Accepted register — CSV](accepted-register.csv) and [exact accepted records — JSONL](accepted-original.jsonl).

- [Full reviewed inventory — CSV, gzip](reviewed-projects.csv.gz) and [full canonical JSONL, gzip](reviewed-projects.jsonl.gz). These retain all 1,198 reviewed records, including planning, qualified, completed and excluded material.

- [Permit-backed-planning lane](permit-backed-planning.csv), [priority gaps](priority-gaps.csv), [state coverage](state-coverage.csv) and [full coverage notes](coverage.json).

- [Accepted source index](accepted-source-index.jsonl), [source-identifier closure](accepted-source-closure.jsonl), [raw-originals manifest](raw-originals-manifest.json) and [independent data audit](independent-data-audit.json). Saved raw originals remain in the research workspace; the manifest records their hashes and paths, not a claim that all original bodies are included in this bundle.

- [Frozen export manifest](manifest.json), [report provenance](report-provenance.json) and [classification figure](record-classification.png).

Blank CSV fields and JSON nulls mean unknown, not zero. The compressed full CSV and JSONL are lossless copies of the frozen export. The PDF is a dated static report; the Markdown copy and accompanying data can be inspected offline.
