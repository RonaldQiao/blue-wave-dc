#!/usr/bin/env python3
"""Reproduce rollups from saved public state counts, or a legitimately obtained building CSV.
No API access, scraping, credentials or invented building rows. Python stdlib only.
Usage: python reconstruct_rollups.py [--buildings authorized-export.csv]
"""
import argparse,collections,csv,json,pathlib
ROOT=pathlib.Path(__file__).resolve().parent

def states():
 rows=json.loads((ROOT/'state-counts.json').read_text())
 keys=['buildings','campuses','operating','under_construction','planned','campuses_planned','campuses_under_construction','campuses_operating']
 assert len(rows)==51 and len({r['state'] for r in rows})==51
 for r in rows:
  assert r['buildings']==r['operating']+r['under_construction']+r['planned'],r['state']
  assert r['campuses']==r['campuses_planned']+r['campuses_under_construction']+r['campuses_operating'],r['state']
 totals={k:sum(r[k] for r in rows) for k in keys}
 out={'state_page_totals':totals,'national_map_minus_state_pages':{'buildings':4601-totals['buildings'],'campuses':1535-totals['campuses'],'operating':1420-totals['operating'],'under_construction':572-totals['under_construction'],'planned':2609-totals['planned']},'coverage_other_status_residual':4729-(2620+572+1425),'coverage_three_status_minus_map':(2620+572+1425)-4601,'scope':'Published counts only; no independent national building-level reconstruction.'}
 return rows,out

def building_rollups(path):
 with open(path,newline='',encoding='utf-8-sig') as f: rows=list(csv.DictReader(f))
 needed={'id','campus_id','state','status','capacity_mw'}
 if not rows or not needed.issubset(rows[0]): raise ValueError('CSV must expose '+','.join(sorted(needed)))
 ids=[r['id'] for r in rows]
 if len(ids)!=len(set(ids)) or any(not x for x in ids): raise ValueError('Duplicate or missing record ID: resolve before counting')
 known={'planned':'Planned','under construction':'Under Construction','operating':'Operating','canceled':'Canceled','cancelled':'Canceled'}
 for r in rows:
  s=r['status'].strip().lower()
  if s not in known: raise ValueError('Unknown status '+repr(s))
  r['status']=known[s]
 live=[r for r in rows if r['status']!='Canceled']
 groups=collections.defaultdict(list)
 orphan=[]
 for r in live:
  if r['campus_id'].strip().lower() in {'','null','none'}: orphan.append(r['id'])
  else: groups[r['campus_id']].append(r)
 campuses=[]
 for cid,rr in groups.items():
  ss={r['status'] for r in rr};status='Under Construction' if 'Under Construction' in ss else 'Operating' if 'Operating' in ss else 'Planned'
  def mw(selected):
   vals=[]
   for r in selected:
    x=r['capacity_mw'].strip()
    if x.lower() not in {'','null','none'}: vals.append(float(x))
   return sum(vals) if vals else None
  cap={s:mw([r for r in rr if r['status']==s]) for s in ['Operating','Under Construction','Planned']}
  campuses.append({'campus_id':cid,'status':status,'building_count':len(rr),'buildings_with_capacity':sum(r['capacity_mw'].strip().lower() not in {'','null','none'} for r in rr),'total_capacity_mw':mw(rr),'capacity_by_status':cap})
 out={'all_records':len(rows),'building_status_counts':dict(collections.Counter(r['status'] for r in rows)),'noncanceled_records':len(live),'noncanceled_state_status_counts':{s:dict(collections.Counter(r['status'] for r in live if r['state']==s)) for s in sorted({r['state'] for r in live})},'campus_count':len(campuses),'campus_status_counts':dict(collections.Counter(c['status'] for c in campuses)),'orphan_noncanceled_record_ids':orphan,'campuses':campuses,'limitations':['Input must contain approved records only, matching documented API eligibility.','Results count records (documented building or phase), not independently deduplicated physical footprints.','Campus-less records remain in building counts and are flagged; no campus IDs are invented.','MW sums represent full record capacity in a status, not necessarily unfinished increments or actual consumption.','Campus state assignment and minimum/maximum operating-year rolls omitted: these need the full campus export for a robust cross-check.']}
 return out

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--buildings');a=ap.parse_args()
 if a.buildings: out=building_rollups(a.buildings)
 else:
  rows,out=states()
  with (ROOT/'state-counts.csv').open('w',newline='') as f:
   fields=['state','buildings','campuses','operating','under_construction','planned','pipeline_buildings','campuses_operating','campuses_under_construction','campuses_planned','source_date','source_url']
   w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
   for r in rows: w.writerow({k:(r['under_construction']+r['planned'] if k=='pipeline_buildings' else r.get(k)) for k in fields})
  (ROOT/'reconciliation.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(out,indent=2))
