# Coverage limitations review

Independent saved-file review at 2026-11-07T22:12:13.186739+00:00. Canonical snapshot: `2026-11-07T220720869242+0000-55d1a1c3`.

The 51 state discovery reviews and 1142 reviewed project packets do not establish an exhaustive inventory. The current export contains 1085 record rows and 14 accepted active records; repeated phases, related context and exclusions are included in record counts. Accepted source locators have 0 unresolved identifiers, which does not measure market coverage.

Municipal application, permit, inspection and occupancy searches remain incomplete. Known retained leads also require identity reconciliation. No national zero, complete largest-project ranking, aggregate mixed-basis MW total or small-site immateriality conclusion follows from these reviews.

Initial coverage statements are historical. Later project reviews have resolved some named gaps; this report preserves source vintage and does not reinstate an old capacity, county or access hold. The JSON contains exact paths, SHA256 hashes and JSON pointers for 51 states and their newest reviewed jurisdiction packets.

## Concrete retained leads requiring reconciliation

These are named discovery leads with no named counterpart found in the bounded canonical identity-field comparison. They may be aliases, stale proposals, existing facilities or nonqualifying projects. They are not newly verified facilities.

| State | Retained lead | File locator |
|---|---|---|
|TX|Nexus Hubbard|`runs/construction_researcher_1/TX/leads.jsonl` line1|
|TX|QTS Hall County|`runs/construction_researcher_1/TX/leads.jsonl` line2|
|TX|QTS Howard County|`runs/construction_researcher_1/TX/leads.jsonl` line3|
|TX|Google Meitner|`runs/construction_researcher_1/TX/leads.jsonl` line5|
|TX|Google Haskell|`runs/construction_researcher_1/TX/leads.jsonl` line6|
|TX|Google Midlothian|`runs/construction_researcher_1/TX/leads.jsonl` line7|
|TX|Meta El Paso Seafox|`runs/construction_researcher_1/TX/leads.jsonl` line8|
|TX|Meta Temple|`runs/construction_researcher_1/TX/leads.jsonl` line9|
|TX|EdgeConneX Cedar Creek|`runs/construction_researcher_1/TX/leads.jsonl` line10|
|TX|Hut8 BeaconPoint|`runs/construction_researcher_1/TX/leads.jsonl` line11|
|TX|Cipher Stingray|`runs/construction_researcher_1/TX/leads.jsonl` line12|
|TX|Cipher BlackPearl|`runs/construction_researcher_1/TX/leads.jsonl` line13|
|TX|AWS Pacifico Pecos|`runs/construction_researcher_1/TX/leads.jsonl` line18|
|TX|Fluidstack RioHondo|`runs/construction_researcher_1/TX/leads.jsonl` line19|
|TX|ECL TerraSite|`runs/construction_researcher_1/TX/leads.jsonl` line20|
|TX|SB Energy Stargate Milam|`runs/construction_researcher_1/TX/leads.jsonl` line21|
|VA|AWS Cosner / Summit Crossing / Carter Store / Mattameade|`runs/construction_researcher_2/VA/leads.jsonl` zero-based JSONL row1|
|VA|CloudHQ LC8 / LC9 / LC10|`runs/construction_researcher_2/VA/leads.jsonl` zero-based JSONL row4|
|VA|Cologix ASH2 / ASH3|`runs/construction_researcher_2/VA/leads.jsonl` zero-based JSONL row4|
|VA|STACK Berry Hill Project Crossroads|`runs/construction_researcher_2/VA/leads.jsonl` zero-based JSONL row6|
|NJ|Digital Realty Piscataway EWR11 / EWR12 / EWR20|`runs/construction_researcher_1/NJ/leads.json` /unverified_discovery_leads/10|
|NJ|Iron Mountain Edison NJ1 / NJ2|`runs/construction_researcher_1/NJ/leads.json` /unverified_discovery_leads/11|
|NJ|Bell Works Holmdel|`runs/construction_researcher_1/NJ/leads.json` /unverified_discovery_leads/13|
|NJ|Earth Station76 Logan Township|`runs/construction_researcher_1/NJ/leads.json` /unverified_discovery_leads/17|
|NJ|PSEG Salem / Hope Creek exploration|`runs/construction_researcher_1/NJ/leads.json` /unverified_discovery_leads/16|

## Specific route limits in already reviewed files

|State|Latest reviewed route limitations (bounded excerpts)|
|---|---|
|AK|HoustonAIDEA18ppapplicationnowreadable; MatSuRS26-019legislationdetailpassedstatusnoworiginalverified|
|AL|All67county/municipalinspectionregistersremainnotexhaustivelysearched; Prichardoriginalpermit/parcelunread; threshold8MWexclusionresolved|
|AR|Everymunicipalitypermit/inspectionportalnotsearched; Clarksvillebuildingpermit/finalCO/July20meetingrecord|
|AZ|Goodyeardevelopment/recordspages403; ChandlerAccela403|
|CA|Noactualbuildinginspectionorissuedpermit; Noactualinspection/courtscanunread;citynotcountypermittingauthority|
|CO|All64county building/inspection systems remain open as a systematic census. County-specific primary reads were limited to Weld land-use release and Denver county attribution in state air permit.; Allmunicipal building/inspection systems remain open as a systematic census. Aurora four permitGISrows and ColoradoSpringsplanningdocket are selected reads, not completed jurisdiction inspection coverage.|
|CT|Correct Waterford March17 packet located, substantive scan gap persists; Bloomfield town conceptual article and original building address|
|DC|Current2025/2026 address queries inaccessible; SCOUT zero-text; eRecords redirect failed.; No actual building inspection/CO or primary OCTO60Florida lease crosswalk.|
|DE|Details 572; no building inspection/GIS completeness; Not parcel permit search or proof of later ban enactment|
|FL|Noexhaustive67county/allmunicipalpermitsearch; FloridaDEPairsearchdidnotproduceproject-specificoriginalpermit; noDEPportalallrecordsqueryclaimed|
|GA|Noexhaustiveall159county/municipalitypermitinspectioncensus; RegistrybeforeJanuary2023andmissingline544unread;industrial/mixedusename-onlyentriesremainunclassifiedinregistry-window|
|HI|HonoluluDPPactualbuilding/inspectionportalnotqueried; exactServpacBuilding2/AlohaNAPpermitandlatestcompletionneeded; AlohaNAPphase-labelconflict2025specPhaseI5MWvs2026video1.5MWvswebsitePhaseIII50000sf; physicalcurrentphase/boundaryMWunresolved|
|IA|Waukee current submissiontable and two original staffreportscopes; Ameslaterstudycommitteehistory|
|ID|KunaRDSindividualfacilityMW/latestprimaryphysicalmilestoneandallocatedinspections/COheld.; Parcel3000/3001/2400historyandCole/KunaMoraindividualsitecrosswalkunresolved.|
|IL|IllinoisAccela/inspection/projectdevelopment/documentgateway403, noindividualbuildingCOorinspectionquery; CaliforniaElkGrove.govpermittoolnotapplicable.; Prime1501EMidwayPIN08224030160000vs1650EHigginsmailingdistinction;individualbuildingaliasjoinnotclosed.|
|IN|SpecificBDpermit-to-DCbuildingnumberandaccomplishedinspection/currentCO; Facilityelectricaldesign>20separatefromcampus/generator/chipcount|
|KS|Everymunicipalitypermit/GIS/inspectionregisternotsearched; PilotactualbuildingexcavationfoundationinspectionandindividualfacilityMW|
|KY|IndividualCBphysicalstage/workallocationheld; Noactualbuildingpermit/inspection/COrow|
|LA|WestFeliciana PILOT lease/map redirected filesusr inaccessible; DEQ15291371Forbidden;15227214 downloadJSonly|
|MA|SpecificMarkleyelectricalpermitnumber/address/parcelcode; Completionlimitedtooffices/storage, notdatahall|
|MD|Frederickentityinspection/COquerynotexposed,CIVICSshell; BauxiteIIOct14packet180.5MB/III153.9MB/AlignedJanuary52.7MBtoolsizefailure|
|ME|Noall16county/allmunicipalpermitcensus; LoringLimestone/LDAactualbuildingpermit/inspectionandVersantwillserveagreementnotretrieved;115ksfleasevs26/50MWscopeunresolved|
|MI|Saline building-specific capacity, permits, passed inspections and latest first-building completion/CO remain unresolved.; Google October14 final plan/minutes, current building permit and accomplished physical start unresolved; wetland application not issuance.|
|MN|PineIsland23ppsettlementnowreadableoneleasedDCandconstructionrestrictions; MonticelloOct19futurebuilding/siteplanallocationexplicit|
|MO|No actualbuildinginspection/CO read inthispacket; WarrentonOct6originalminutesnotexposed; AIreportedsiteworkqualifiedonly|
|MS|{"resource": "MDEQ July Southaven NOV investigation PDFs linked by Mississippi Today", "result": "Repeated supported web opens failed; no claim originals inspected", "raw_files": ["raw/s3.json", "raw/s10.json"]}; {"resource": "Brandon CivicClerk meeting portal", "result": "403 Forbidden", "raw_file": "raw/s23.json"}|
|MT|QuanticaPWSdesignreport10.8MBtoolsizefailure; NYDIG5357-01/5361-00andEAunsupportedDOCX;cannotreadconditions/location|
|NC|New route: NC DAQ comprehensive application XLSX/register explicitly not queried in reviewed coverage. Recover original current tabular records, filter datacenter/LLC aliases, reconcile issued vs pending and existing known facilities; retain all new qualifying leads with municipality/county and original progress checks. Generator ratings never IT. Avoid repeating QuickLook25page summary.; Comprehensive XLSX rows and milestone event columns unread; targetgap remains open. Need supported binary-download access, no proxy bypass.|
|ND|All53county/municipalinspection/COsweepincomplete; no exhaustive statewide absence.; PF1thirdELN04exactalias/municipalconditionalpermitfee/currentpassedinspection/CO; EllendaleDrivefolderunread.|
|NE|GooglePapillionB4/B5physicalprogressoriginalandlatestfinal/CO,individualfacilityMW,SRP6Amappingdedup; currentissuedpermitsdonotproveactualinstallation.; GoogleLincolnactualbuilding-specificinspection/physicalcurrentexpansionandindividualfacilityMW;DWEEannualDCRviewershellinaccessible.2026onlinewholecampusnotallfuturebuildingsfinished.|
|NH|DirectFERCfileid5F1988FA-75DB-C446-98FF-9DBAF5000000andfilelist0lines; no originalexhibits; Cloudpermitlogin/AxisGIS0lines; no parcelinspectionorcoordinates|
|NJ|OfficialSocratacatalog3lineshell/APIresourceandmetadata inaccessible; actualdatasetrowsnotqueried. Indexedmetadataunaudited60month/missingaddresslimitationsheldindex-only.; DevelopmentViewerbinaryExceltoolsizeblocked;PowerBI0textnoactualfiltersorimagery.|
|NM|IndividualbuildingMW/parcel/permitnumbers/inspectionCOunknown;countyredirectinaccessible;airnotice503,docketLoading; Noactual2026newbuildingstart/currentinspection;CIDJSblank;noindividualfacilityMW|
|NV|RegionalAccela/onenv403preventsindividualbuildinginspection/finalCO forApple/Centra/Oppidan; AppleexactnumberedbuildingfacilityMW/currenttrade vsSunolsubstation300MW; utilityAPNsnotDCfootprint|
|NY|62-county statewide municipal census not completed; broader lead discovery recorded in raw01; Alabama actual building permits, inspections, parcel GIS and latest field status|
|OH|UnionCountyJanuary–October2026commercialXLSXrowsunread: webunsupportedformat/DriveinvalidnonDriveURL; no report absenceclaim.; HilliardViewpoint403; noindividualbuildinginspection/COhistory.|
|OK|All77county/municipalpermitinspectioncensusincomplete;boundedCore/Hostgapdeepeningonly.; CoreMuskogeesecondactualpermit/inspection/CO,buildingfootprint/phaseaddressandcurrentunfinishedMWremainheld; primaryrelativewallmilestonedateexactonlysecondarymirror.|
|OR|{"url": "https://www.hillsboro-oregon.gov/community/data-centers", "reason": "403;indexedgovernmenttextonly"}; {"url": "https://www.morrowcountyor.gov/", "reason": "robotsrestrictionforplanningpacket;indexedgovernmenttextonly"}|
|PA|No entitybuildingpermit/inspection/CO ledger; SharonNOI/GIF/COAtimeout;exactparcel/buildingbasisunresolved|
|RI|No complete39municipalbuilding/inspectionportalquery; fivecountiesnotcertifiedabsent.; HantonPLN26-10masterplanbody,latestcompleteness/appeal/courtorder,actualDCbuildingMW/startandcounty/sitecoordinatesstillheld;Smithfield403.|
|SC|No46county/allmunicipality permit census; parentcoverage gaps remain; QTS specificDC1/DC2 original permit crosswalk and >20MW electrical facility proof; no inspection/CO|
|SD|All66 county building/inspection systems remain unsearched systematically, including Minnehaha, McPherson, Sully, Deuel and Pennington markets.; All municipalities remain open for building permit/inspection census. Sioux Falls planning read is not building-inspection coverage.|
|TN|Noall95county/allmunicipalitypermitinspectionCOGIScensus; MemphisDevelop901Accela403;locatoronlysixmonthsafterclosureandnoqueriedpoints;notnegativeinventory|
|TX|City permit dataset and BuildSA each returned 403. Separate CKAN catalog and public resource APIs were inaccessible. No actual site permit, inspection or occupancy rows were read.; Legacy application returned one text line and no record rows. Official legacy scope is issued permits through November 2020.|
|UT|Novva72MWPhase3 highestverifiedindividualpriority: retrieveactualcurrentDCinspection/final/progress;Phase2operatingcounterevidence. September10gasengineprotocolOctober19scheduledtestnotactualDCtest.; QTScurrent3buildingsunderwaybutindividualfacilityMWwithheld;FIRSTvsTHIRDtopoutconflict;latestdatedMEP/COandbuildingidentitiesneeded. Future4/5planreviewnotstart. QTSFairfield/EagleMountainIIaliasesdedup.|
|VA|Noallcountybuildinginspection/finalssearch; reportingtablesnotreadable andscreenshotnoimagepayload; NativeGIS7lineshellnoparcelgeometry/ownerquery; no exactbuildingfootprints|
|VT|Noall14county/allmunicipalitypermitinspectionCOGIScensus; Vernondynamicmeetingformnoactualqueryresults/minutes;municipalnewsnotapplication/tenantcommitment|
|WA|No all39county/allmunicipalpermit census. Seattle/King/Snohomish/Pierce/Spokaneexpansionsbroadlydiscoveredbutnotallinspected.; MicrosoftMalagafirsthandSep17progress strong but exactbuildingIDs,individualMWandnewerprimarydeveloper/inspectionnotretrieved.288MWutilitycampusnotIT. Treasurerparcelnotlinkedexactbuilding.|
|WI|Green Bay January–October2026 issued-project reports all opened and screened for fourterms. NoDCmatch found, but alternatealiases,unissuedapplications,inspections/finalsnotexhaustivelyenumerated.; Old2023 hospitalrelocation notcurrentactiveproof. Pendingzoninglist bounded only.|
|WV|SWP26-0002/3timeouts; Cumulus11.96MBsizefailure|
|WY|OpenGovblank;oldportalretired;noactualbuildingpermit/CO/inspectionrecords;GISblank; Countyactualpermits/buildinginspectionnotretrieved;generationnotDCstart|

The full JSON preserves additional excerpts and the complete source-file locators. A portal error, stale report, unreadable image or unexecuted search is an access limitation, not evidence of no construction. Detailed county-wide and city-wide denominators remain unenumerated in many states.

Represented large candidates such as Helios, Sweetwater, Frontier and Vineland retain their individual-building, physical-work, current-status or unfinished-MW holds. Capacity normalization does not promote construction acceptance.

Current worker lead audits are pending separately. This report changes no canonical classifications, queue statuses or source files.
