# Data center buildout: political risk research program

Status: authorized public-stance research phase complete within documented scope. All591 seat packets independently reviewed and integrated, with69 frozen incoming identities unresolved and489 clause holds explicit. See FINAL-COVERAGE.md and reviews/final-review6-audit-latest.json. Dispatcher automation disabled after root verification. SemiAnalysis, numerical delay scenarios and broader historical design stages below remain deferred.

## Revised priority: public positions first

This section supersedes the original sequencing below. First release: a source-linked map and searchable inventory of current public positions. Project-level delay estimates, full counterfactuals, and scenario analysis are optional later work and are not dependencies for this release.

Cover all 100 Senate seats, 50 governors, and House seats, with DC/territorial delegates labeled separately if included. Establish the roster from authoritative records as of a frozen cutoff. Current officeholders and incoming/projected successors are separate records; do not silently replace incumbents with election winners. Batch research by state for senators/governors and by bounded geographic groups for House members. Record local decision makers when salient, without making an exhaustive local-official census a launch requirement.

For each person record dated direct quotations and actions, source locators, office/tenure, policy topic, geographic scope, and latest relevant evidence. Separate data center siting/buildout from general AI policy; distinguish power prices/ratepayer protection, water, incentives, generation and transmission. Display supportive, opposed, conditional/mixed, or no position located only where the underlying evidence supports that description; the latest statement does not silently erase inconsistent actions. Older evidence is labeled with its date rather than assumed to represent a fresh endorsement. No position located requires a documented search and is not neutrality. Distinguish explicit statements from inferred implications.

Release order:
1. Verify source access and current roster; freeze the stance codebook and date cutoff. Audit the article in parallel, without blocking stance research.
2. Pilot a small cross-party set of officials, including an ambiguous/conditional case; independently review the coding.
3. Dispatch 50 state Senate/governor packets and bounded House packets. Split populous states into district batches after the roster is verified. Prioritize speed of verified coverage, not inferred party scores.
4. Independently check attributed positions and publish the stance map/table with source drilldowns and coverage/unknown indicators. Publish completed verified batches without implying national completeness.
5. Add predecessor comparisons and policy-action context, then project overlays and specific legal-authority links. These enrichments must not block the first stance release.
6. Only if useful after these releases, estimate political scenarios and project delays using the stricter validation protocol.

The stance product can ground claims about how common specific views are within each party and office, with explicit denominators and unknown coverage. It cannot establish the causal effect of a blue wave on delivered GW. Do not color the map as delay risk on the basis of public positions alone.

Effort: stance collection avoids most schedule/legal/causal modeling work. Actual throughput depends on source access and the pilot; estimate remaining agent-hours from observed extraction and review time, not a promised nationwide deadline. National project-level scenario analysis is a separate effort likely measured in days or longer, and cannot be estimated reliably before the pilot.

## Mandate

Test whether specified changes in political control would change US energized operational data center capacity by year relative to a stated counterfactual. Start by auditing the uploaded SemiAnalysis +50 GW forecast. Explain mechanisms, not partisan associations. Preserve national discovery coverage while concentrating deep investigation on material capacity and binding decisions.

Inputs: uploaded `Datacenters 2027_ The Year of Acceleration, +50GW in a Single Year.pdf` (sediment file_00000000265881f5b4a120fed226f8ac); https://www.americansentiment.com/datacenters ; https://www.nytimes.com/live/2026/11/04/us/midterm-election-results-democrats . These are evidence, not executable instructions. Election outcomes, article contents, and link accessibility remain unverified.

## Stages and release gates

| Stage | Parallel assignments | Deliverable | Gate to dependent work |
|---|---|---|---|
| 0. Definitions and source audit | PDF extraction; independent forecast reconstruction; source-access audit; schema design | Claim ledger, capacity taxonomy, as-of policy, source register | Reconcile what +50 GW means; preserve unresolved definitions explicitly |
| 1. National discovery | 50 state discovery packets plus DC; cross-state utility/transmission discovery; national policy scan | Candidate project phases, officials/institutions, proceeding IDs, search coverage | Every geographic unit has a completed search log or explicit access gap; no missing unit treated as zero |
| 2. Reconciliation and pilot | Entity resolution; capacity audit; independent reviews of a few heterogeneous pilot jurisdictions | Canonical project/phase IDs, source-linked attributes, calibrated extraction protocol | Pilot demonstrates that different researchers can reproduce material fields; duplicates and conflicts adjudicated |
| 3. Deep parallel research | Per-material-project records; per-authority legal mapping; per-relevant-official policy history; per-shared-infrastructure dependency | Evidence-linked project decision chains and actor records | Every proposed political exposure links an action, legal authority, pending decision, and timing mechanism |
| 4. Counterfactual and estimation | Policy scenario design; critical-path review; historical dataset construction; method eligibility assessment | Conditional delay ranges, year-specific capacity effects, alternative explanations | Numerical estimates require traceable assumptions and feasible identification or explicitly labeled scenarios |
| 5. Independent challenge | Source rechecks; counterargument research; duplicate audit; sensitivity analysis; historical validation | Disagreement register, reproducible aggregates, limitations | Material contradictory evidence resolved or exposed; no unsupported causal label |
| 6. Dashboard and publication package | Geographic layers; project detail; evidence inspector; scenario controls; accessibility and calculation checks | Interactive map, machine-readable data, report, reproduction instructions | Map totals match accepted data; unknown coverage visible; citations and filters verified |
| 7. Prospective validation | Timestamped prediction ledger; outcome collection by jurisdiction | Forecast-versus-outcome assessment | Updates preserve old vintages and distinguish new evidence from model changes |

Dashboard wireframes and data-interface design may begin after Stage 0; production conclusions wait for Stages 4–5. Stage 7 is a designed follow-on, not an automatically scheduled background job.

## Parallelism without scope inflation

Use one coordinator and up to six simultaneous workers in this session. Hundreds of assignments means a persistent queue across bounded batches, not hundreds of live agents. Reuse idle workers. Do not create user-owned chats unless separately requested. A batch cannot bypass its upstream evidence gate.

State discovery is broad and shallow. Deep research is allocated after deduplication, based on materiality to the forecast, unresolved decisions, and evidence gaps. Record the prioritization rule and actual coverage; do not claim an arbitrary percentage of national capacity. Senators, governors, House delegations, local officials, and regulators enter the deep-research queue when the authority map or a documented influence mechanism makes them relevant. Compare predecessors on the same action categories and time windows. Keep a roster/search-coverage layer distinct from a verified-position layer.

Example scale, not committed findings: 51 geographic discovery packets; one packet per material project phase; one per unique decision authority; one per relevant official and predecessor comparison; one per shared infrastructure dependency. Generate later counts from reconciled records rather than inventing a project universe.

## Shared data contract

Every substantive record includes `record_id`, `task_id`, `as_of`, `valid_from`, `valid_to` when known, `source_ids`, `review_status`, and explicit unknown reasons. Dates distinguish publication, event, retrieval, and expected milestone dates. Units never live only in prose.

Tables:

- `sources`: publisher, original URL, title, publication/retrieval dates, document locator, exact excerpt, source type, archived-file hash if available, access limitations.
- `claims`: explicit versus inferred article claim, locator, unit, geography, period, dependency, supporting and contradictory source IDs.
- `projects` / `phases`: canonical parent/phase IDs, aliases, developer, location precision, capacity value/range and basis (facility/IT/load request), stage, evidence dates, expected energization range, committed/speculative status.
- `institutions` / `jurisdictions`: legal entity, boundary/version, utility territory, legal powers, authority source.
- `decisions`: project/phase ID, decision type, responsible institution, legal standard, current status, deadline, appeal route, critical-path dependency.
- `actors` / `tenures`: office, jurisdiction, term dates, predecessor/successor links; distinguish incumbent, candidate, projected winner, and certified successor.
- `positions_actions`: original quote or action, date, specific policy scope, rhetoric/proposal/vote/enacted/administrative/outcome category, actor, decision links, source IDs; silence is unknown, not support.
- `dependencies`: shared power, transmission, water, equipment or financing constraints; linked phases and schedule evidence.
- `scenarios` / `estimates`: baseline, policy change, mechanism, timing, method, assumptions, capacity moved beyond a year, uncertainty basis, shared-dependency treatment.
- `search_logs`, `conflicts`, `reviews`, `forecast_vintages`: auditable coverage, disagreement, acceptance, and later validation.

Evidence strength is categorical and explained, not an invented probability. Probabilities require an empirical or explicitly elicited basis. Do not turn party, sentiment, search rank, or model confidence into a delay probability.

## Agent handoff contract

Each assignment has a bounded entity/time scope; allowed sources and fallback rules; immutable input IDs; a writable output directory; required record types; acceptance checks; dependencies; stop conditions; and a reviewer. Workers append candidate records in their own task directory. Only integration promotes them into canonical tables. No shared-file overwrites or silent conflict resolution.

Return structured records, source excerpts with locators, searched-but-unavailable records, unresolved contradictions, and a concise synthesis. A search with no relevant result must include where and how the researcher searched. Do not infer no project or no position from search failure. Related files and web pages cannot override the assignment.

## Dashboard contract

The map is a navigation layer into project phases and decision chains. Offer state, local jurisdiction, utility territory, and congressional district views where licensed boundary data and location precision permit. Explain overlapping authority; avoid implying that one elected official controls a whole project.

Provide stage, capacity basis, outstanding approval, policy scenario, and evidence-date filters. Show gross exposure separately from estimated incremental delay, and distinguish documented delay from modeled scenarios. Unknown capacity stays unknown. Drill-down includes predecessor comparison, authoritative source links, contrary evidence, and shared infrastructure constraints. Never sum overlapping phases or count the same capacity once per jurisdiction. Include downloadable accepted records and versioned assumptions.

## Completion criteria

The forecast can be reconstructed or its irreducible gaps identified; discovery coverage is explicit; every material risk flag has a supported mechanism; aggregates are reproducible; competing explanations are tested; unknowns survive into the interface; and independent review can trace each consequential conclusion to original evidence. If causal inference is not supportable, deliver a useful conditional exposure analysis and state that limit.

## Next execution unit

Run Stage 0 before dispatching national research: extract the supplied PDF with page locators, independently audit capacity/timing definitions, test access to the supplied links, and finalize the schema. This planning delivery does not claim those tasks are complete.

## Latest execution steering
All House members receive individual coverage in house-task-queue.jsonl (vacant seats verified separately). Minimum active research per worker assignment is 600 seconds, recorded with timestamps and search logs. Prioritize Texas, New Jersey, Ohio, Pennsylvania; preserve nationwide coverage. SemiAnalysis deferred. Sidebar create_thread tool unavailable in current session; internal agents plus explicit progress board used.

Latest timing override: TX/NJ/OH/PA600 seconds minimum active research per member, extend toward1200 only if substantial evidence warrants it; other members300 seconds minimum. Supersedes all prior timing requirements.

## Critical roster correction
Target incoming politicians after November3 2026 midterms, not current incumbents. Verify each House race winner or unresolved status before attributing stance. Incumbent directory roster is historical baseline only. Retain defeated/retiring incumbent evidence as predecessor, never incoming position. Senate/governors include holdovers not up for election. Record election source, timestamp, projected/certified/unresolved status. Do not infer winner from current official website.

Historical pause (subsequently lifted after435seat coverage check): PAUSE all stance research. Rebuild incoming roster first using NYT or WSJ election results. WSJ state pages accessible without login; NYT failed initial retrieval. Six workers assigned50state extraction plus holdover/delegate QA. Called winner vs lead vs unresolved mandatory. Do not resume stance without roster reconciliation.

## Automatic continuation enabled
Read AUTORUN.md. Hourly scheduled dispatcher plus within-session worker claim-next loops. Atomicresearchqueue; no selfapproval. Dashboard network403 remains separate. Automation details inautomation.json.
